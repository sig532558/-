// 혜성물류 ERP 업무 스케줄러가 기대는 공통 함수 (원본 파일에서 그대로 발췌 · 2026-11-20)
// 29-schedule.js가 부르는 함수 중 정리현황 표 계산에 꼭 필요한 것만 모음 — 나머지는 '00_클로드에게_먼저_읽기.md'의 목록 참고

// ===== 출처: js/01-config.js (29줄) =====
const HOLIDAYS = new Set([
  // 2026
  '2026-01-01', '2026-02-16', '2026-02-17', '2026-02-18', '2026-03-02', '2026-05-01', '2026-05-05', '2026-05-25', '2026-06-03',
  '2026-07-17', '2026-08-17', '2026-09-24', '2026-09-25', '2026-10-05', '2026-10-09', '2026-12-25',
  // 2027
  '2027-01-01', '2027-02-08', '2027-02-09', '2027-03-01', '2027-05-03', '2027-05-05', '2027-05-13', '2027-07-19', '2027-08-16',
  '2027-09-14', '2027-09-15', '2027-09-16', '2027-10-04', '2027-10-11', '2027-12-27',
]);

// ===== 출처: js/01-config.js (37줄) =====
const isWorkday = d => { const w = new Date(d + 'T00:00:00').getDay(); return w !== 0 && w !== 6 && !HOLIDAYS.has(d); };

// ===== 출처: js/01-config.js (118줄) =====
const SEASONS = ['봄', '여름', '가을', '겨울'];
// 최종반품 차수 (예: 3091차 = S/S시즌에 매장이 못 보낸 상품을 마지막으로 받음) — [차수별 시즌 지정]에서 고름 · 같은 시즌 재고라 S/S · F/W 합계에 포함 · 봄 · 여름 등 낱개 시즌에는 안 들어감 (마스터 2026-11-11)

// ===== 출처: js/02-utils.js (4줄) =====
const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
// 바코드 정리: 대문자 + 영문/숫자만 남김 (하이픈·공백 제거)

// ===== 출처: js/02-utils.js (15줄) =====
const fmt = n => Number(n || 0).toLocaleString('ko-KR');

// ===== 출처: js/02-utils.js (25줄) =====
function todayStr() {
  const d = new Date();
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
}

// 여러 형태의 날짜를 YYYY-MM-DD로 통일 (엑셀 날짜 숫자, 2026.10.01, 20261001 등)

// ===== 출처: js/12-style-sorter.js (198줄) =====
const GRP_NAME = { TS: '티셔츠', JK: '자켓', ACC: '악세' };

// ===== 출처: js/12-style-sorter.js (199줄) =====
const grpName = g => GRP_NAME[g] || g;
// 복종별 입수량 (이 화면에서 직접 입력 — 비우면 [소터분류 → 슈트별 입수량] 값)
// 입수량 = [소터분류 → 슈트별 입수량] (상품 시즌의 값 → 슈트 예외가 있으면 그 값)

// ===== 출처: js/08-inbound.js (184줄) =====
function groupOf(style) {
  const code = normBc(style).substr(3, 2), h = icLookup('item', code);
  return h ? (h.vals[1] || h.vals[0] || '').toUpperCase() : '';
}
// 검수 목표 (반품검수조회 상품코드별 전송수량, 시즌 선택 반영) → { 스타일코드: 수량 }

// ===== 출처: js/07-calc.js (184줄) =====
function sorterExcl(rows) {
  const ex = SORTER_EXCL[scopeKey()];
  if (!ex) return rows;
  const ins = inspAnyStyles();
  const by = new Map(), rep = new Map();   // 작업일자 · 스타일마다 (슈트 줄이 여러 개면 앞 줄부터 뺌)
  rows.forEach(r => { if (r.work_date && ex[r.style]) { const k = r.work_date + '|' + r.style; (by.get(k) || by.set(k, []).get(k)).push(r); } });
  by.forEach((rs, k) => { const st = k.slice(k.indexOf('|') + 1); let left = ins.has(st) ? ex[st] : Infinity;
    rs.forEach(r => { const cut = Math.min(left, r.qty || 0); if (!cut) return; left -= cut; const q = (r.qty || 0) - cut;
      rep.set(r, Object.assign({}, r, { qty: q, boxed_qty: Math.min(r.boxed_qty || 0, q) })); }); });
  return rep.size ? rows.map(r => rep.get(r) || r) : rows;
}

// ===== 출처: js/07-calc.js (273줄) =====
function sorterDeltaBy(list, keyOf) {
  const by = {}, out = {}, last = {};
  list.forEach(r => { if (!r.work_date) return; const m = by[r.work_date] = by[r.work_date] || {}; m[r.style] = (m[r.style] || 0) + (r.qty || 0); });
  Object.keys(by).sort().forEach(d => { const o = out[d] = {};
    Object.keys(by[d]).forEach(s => { const n = by[d][s] - (last[s] || 0); if (n > 0) { const k = keyOf(s); o[k] = (o[k] || 0) + n; } last[s] = by[d][s]; }); });
  return out;
}
// 작업일자별 그날 분류를 묶음(복종 · 시즌 등 keyOf(스타일))별로 → { 작업일자: { 묶음: 장 } } — sorterDaily와 같은 계산 (스타일마다 늘어난 만큼)

// ===== 출처: js/28-prod.js (10줄) =====
const prodHeads = (f, t) => { const D = (state.staff || {}).dates || {}, o = {}; Object.keys(D).filter(d => d >= f && d <= t).forEach(d => { const n = staffIn(D[d].cos); if (n) o[d] = n; }); return o; };

