/* ---------------- 대시보드 › 업무 스케줄러 (큰 달력) ----------------
   · 출고: 택배사 배송현황(출고일 · 박스) · 포승이관(이관일 · 박스) — 확정 전은 "예정"
   · 소터 분류: 지난 날 = 실제 분류 장수 · 앞날 = 복종별 끝나는 날 예상
     남은 장수 = 고른 시즌의 검수 끝난 장수 − 분류한 장수 (아직 검수 안 된 예정은 넣지 않음 — 추정치 금지, 마스터 2026-11-02)
     하루 장수 = 그 복종만 한 날(그날 분류의 90% 이상)의 최근 5일 평균(실제) → 없으면 직접 넣은 값 → 그것도 없으면 최근 5일 전체 평균(추정)
     한 번에 분류(봄 등): 그 시즌만 한 날(90% 이상) 최근 5일 평균(실제) → 직접 넣은 값 → 최근 5일 전체 평균(지금 분류 중인 여름 기준 추정) — 분류를 시작하면 실제로 자동으로 바뀜 (마스터 2026-11-02: 스케줄러만 추정치 허용)
     복종은 진행 순서대로 하나씩 끝냄 (하루를 다 못 채우면 남은 시간에 다음 복종) · 토 · 일 · 공휴일은 건너뜀
   · 시즌 일정표(네파 시즌반품 진행 현황판): 반품 지시 · 매장반품 기간 · 검수확정 마감 · 복종별 가용화 예정 · B2B · 재고이관 · 주차별 계획
     → app_settings 'seasonPlan' { 화주사: { name, base, items:[{ c 센터, k 종류, d, d2, t, ... }] } } · 지금 센터 것 중 SP_SHOW(반품 최종일 · B2B 출고 · 재고이관 완료)만 보여 줌
   · 설정(관리자): 시즌 · 진행 순서 · 하루 장수 직접 입력 → app_settings main.sched[화주사|센터] */
const SC_SOLO = 0.9, SC_N = 5;
const SC_COL = ['#0F2A5C', '#0E7490', '#B45309', '#7C3AED', '#15803D', '#BE185D'];
const sch = { ym: '', cache: {}, open: false };
// 스케줄 설정 · 일정은 app_settings 'sched:화주사|센터' 따로 저장 → 관리직 이상 저장 가능 (마스터 2026-11-12) · 예전 main.sched 값이 있으면 처음엔 그걸 씀
const schCfg = () => ((state.schedAll || {})[scopeKey()]) || ((state.settings.sched || {})[scopeKey()]) || {};
const schCan = () => typeof isManager === 'function' && isManager();   // 일정 · 인원 · 설정 고치기 = 관리직 이상
async function schSave() { const k = scopeKey(); await DB.upsert('app_settings', [{ key: 'sched:' + k, value: (state.schedAll || {})[k] || {} }], 'key'); }
/* ---------------- 다른 브랜드 소터 분류 (마스터 2026-11-16: 크리스 · 밀레) ----------------
   크리스(품번체계 10자리 · 첫 자리 브랜드 코드) · 밀레(분류 대상 파일의 스타일) 소터 파일은 네파 소터 자료(sorter_result)에 넣지 않고 따로 셈
   (네파 자료에 넣으면 그 작업일 네파 분류가 통째로 바뀌고 수불 장부 가용화에도 들어감)
   → uploads[화주사|센터].brandSort = { tgt: { 밀레: { file, at, by, total, st: { 스타일: 장수 } } }, d: { 브랜드: { 작업일: { 스타일: 누적 장수 } } } }
   · 분류 장수는 브랜드 총수량으로만 셈 (시즌 · 복종 나누지 않음) = 스타일마다 가장 큰 누적 장수의 합
   · 업무 스케줄러 일정 추가 중 이름에 브랜드가 들어간 일정(예: 「크리스」 · 「밀레」)에 진행률 · 남은 장수로 적용 */
const brSortAll = () => (((state.settings.uploads || {})[scopeKey()] || {}).brandSort) || {};
const brNames = () => ['크리스', '밀레'].concat(Object.keys(brSortAll().tgt || {})).filter((b, i, a) => a.indexOf(b) === i);
const schExBrand = e => (e.br && brNames().includes(e.br) ? e.br : '') || brNames().find(b => String(e.nm || '').includes(b)) || '';   // 일정 추가에서 고른 브랜드 먼저 (마스터 2026-11-19)
// 소터 줄 나누기: 네파 / 브랜드별 (스타일 → 장수) / 어디에도 없는 품번 (네파 모양이 아닌데 브랜드도 모름)
function brandSortSplit(rows) {
  const T = brSortAll().tgt || {}, look = [];   // [브랜드, 스타일 Set, 스타일 길이들]
  Object.entries(T).forEach(([b, o]) => { const s = new Set(Object.keys(o.st || {})); look.push([b, s, [...new Set([...s].map(x => x.length))]]); });
  const of = st => { const k = normBc(st); if (!k) return ['', k];
    if (k.length === 7 && icLookup('brand', k[0])) return ['', k];   // 네파 품번
    for (const [b, s, ls] of look) for (const n of ls) if (s.has(k.slice(0, n))) return [b, k.slice(0, n)];
    // 크리스: 브랜드(1자리) · 성별 · 구분 · 년도 · 시즌 자리가 크리스 품번체계 표에 다 있어야 (다른 긴 코드가 크리스로 잘못 잡히지 않게 — 검수 지적)
    const cr = (part, c) => IC_CREAS[part].rows.some(x => x.code === c);
    if (k.length >= 10 && typeof IC_CREAS !== 'undefined' && cr('brand', k[0]) && cr('gender', k[1]) && cr('kind', k[2]) && cr('year', k[3]) && cr('season', k[4])) return ['크리스', k.slice(0, 10)];   // 품번 10자리 (바코드면 앞 10자리)
    return ['', k]; };
  const by = {}, nepa = [], unknown = new Set(); let n = 0;
  rows.forEach(r => { const [b, k] = of(r.style);
    if (!b) { nepa.push(r); if (k && !(k.length === 7 && icLookup('brand', k[0]))) unknown.add(k); return; }
    const m = by[b] = by[b] || {}; m[k] = (m[k] || 0) + (+r.qty || 0); n++; });
  return { by, nepa, unknown: [...unknown], n };
}
// 저장: 최신 업로드 기록을 다시 받아 그 위에 고침 (다른 PC가 올린 것 안 지움)
async function brandSortSave(fn) {
  if (DB.isRemote()) await refreshUploads();
  const U = state.settings.uploads = state.settings.uploads || {}, S = U[scopeKey()] = U[scopeKey()] || {};
  fn(S.brandSort = S.brandSort || {});
  await DB.upsert('app_settings', [{ key: 'uploads', value: U }], 'key');   // 연결 안 된 모드도 저장 (saveUploads와 같게)
}
// 일정 추가 구분 (마스터 2026-11-19): 분류 · 출고 — 예전 일정은 이름에 「출고」가 있으면 출고
const schExKind = e => e.kind || (/출고/.test(e.nm || '') ? '출고' : '분류');
// 크리스는 시즌별로 분류 실적을 나눔 (품번 다섯째 자리 = 시즌 · 마스터 2026-11-19: 여름 자켓을 추가했는데 봄 분류 실적을 가져가 11/19로 잡힘)
function schExSf(br, e) {
  if (br !== '크리스' || !e.se || typeof IC_CREAS === 'undefined') return null;
  const c = (IC_CREAS.season.rows.find(x => x.vals[0] === e.se) || {}).code; return c ? s => String(s).length >= 10 && String(s)[4] === c : null;
}
// 추가 일정의 실제 분류 실적: 출고 일정 = 없음 · 크리스 시즌 일정 = 그 시즌만 · 그 밖은 같은 브랜드 첫 일정만 (뒤에 추가한 일정은 실적을 안 가져가 맨 뒤에 붙음)
function schExG(e) {
  const br = schExBrand(e); if (!br || schExKind(e) !== '분류') return null;
  const f = schExSf(br, e); if (f) return brandSorted(br, f);
  const first = (schCfg().extra || []).find(x => schExBrand(x) === br && schExKind(x) === '분류' && !schExSf(br, x));
  return first && first.id === e.id ? brandSorted(br) : null;
}
// 브랜드 분류 장수: 작업일마다 스타일 누적이 늘어난 만큼 = 그날 분류 · 합 = 분류한 총수량
//  f(스타일) = 이 스타일만 셈 (크리스 시즌 나누기 · 마스터 2026-11-19)
function brandSorted(b, f) {
  const D = (brSortAll().d || {})[b] || {}, ds = Object.keys(D).sort(), mx = {}, day = {};
  ds.forEach(d => { let n = 0; Object.entries(D[d] || {}).forEach(([s, q]) => { if (f && !f(s)) return; const p = mx[s] || 0; if (q > p) { n += q - p; mx[s] = q; } }); if (n) day[d] = n; });
  const dd = Object.keys(day);
  return { done: Object.values(mx).reduce((a, v) => a + v, 0), day, first: dd[0] || '', last: dd[dd.length - 1] || '' };
}
// 브랜드 안 묶음별 분류 장수 (마스터 2026-11-19: 크리스 → 품번 첫 자리 브랜드별) · brandSorted와 같은 계산을 kf(스타일) 묶음으로
function brandSortedBy(b, kf, f) {
  const D = (brSortAll().d || {})[b] || {}, mx = {}, out = {};
  Object.keys(D).sort().forEach(d => Object.entries(D[d] || {}).forEach(([s, q]) => { if (f && !f(s)) return; const p = mx[s] || 0; if (q > p) { const o = out[kf(s)] = out[kf(s)] || { done: 0, day: {} }; o.day[d] = (o.day[d] || 0) + q - p; o.done += q - p; mx[s] = q; } }));
  return out;
}
const CR_BR_ROWS = [['5', '파리', 'PEARLY GATES'], ['4', '마바', 'MASTER BUNNY'], ['8', '세인트', 'ST ANDREWS'], ['1', '핑', 'PING'], ['2', '팬텀', 'FANTOM'], ['L', '링스', 'LYNX']];   // 크리스 브랜드 줄 (마스터 2026-11-19: 한글 이름 · 이 순서) · 품번 첫 자리 · 영문
// 크리스 브랜드 줄 센터 확정 = 오토 RCV에 올린 다른 재고 파일(크리스반품현황 · 링스반품 등) 총재고 (마스터 2026-11-19)
//  rcv_stock owner '화주사|파일:이름' · rows [스타일, 칼라, 사이즈, 수량] · 크리스 품번(10자리)만 → { '시즌코드|브랜드코드': 장수 }
//  올린 시각이 같으면 이 PC 보관본을 씀 (수파베이스 사용량 아끼기)
const SCH_CRST = { v: null, busy: false, at: '' };
// 센터 확정에서 뺄 년도 (품번 넷째 자리 · 마스터 2026-11-19): 파리 · 마바 · 세인트 · 핑은 D(2024) 빼고 · 팬텀은 E(2025) · F(2026) 빼고 · 링스는 전부
const CR_BR_SKIPYR = { 5: 'D', 4: 'D', 8: 'D', 1: 'D', 2: 'EF' };
async function schCrStockLoad() {
  if (SCH_CRST.busy || SCH_CRST.at || !DB.isRemote() || typeof RCVF_PFX !== 'function') return; SCH_CRST.busy = true;
  try {
    const q = DB.base('rcv_stock') + '?owner=like.' + encodeURIComponent(RCVF_PFX() + '*'), H = { headers: DB.headers() };
    const M = await DB.req(q + '&select=owner,uploaded_at', H) || [], at = M.map(r => r.owner + '@' + r.uploaded_at).sort().join(',') || '-';
    let c = null; try { c = JSON.parse(localStorage.getItem('rt_sch_crst2_' + scopeKey()) || 'null'); } catch (e) {}
    if (c && c.at === at) SCH_CRST.v = c.v;
    else { const L = await DB.req(q + '&select=rows', H) || [], v = {}, ok = (p, k) => IC_CREAS[p].rows.some(x => x.code === k);
      L.forEach(f => (f.rows || []).forEach(r => { const st = String(r[0] || '').toUpperCase(), n = +r[3] || 0;
        if (st.length >= 10 && n > 0 && ok('brand', st[0]) && ok('season', st[4])) { const k = st[4] + '|' + st[0] + '|' + st[3]; v[k] = (v[k] || 0) + n; } }));
      SCH_CRST.v = v; try { localStorage.setItem('rt_sch_crst2_' + scopeKey(), JSON.stringify({ at, v })); } catch (e) {} }
    SCH_CRST.at = at; if (typeof renderHomeSched === 'function') renderHomeSched();
  } catch (e) { console.warn('크리스 재고 파일 읽기 실패', e); } finally { SCH_CRST.busy = false; }
}
// 브랜드 코드 · 시즌 이름(비우면 전체) → 재고 장수 (아직 못 읽었으면 null)
const schCrStock = (c, se) => { if (!SCH_CRST.v) { schCrStockLoad(); return null; }
  const sc = se ? (IC_CREAS.season.rows.find(x => x.vals[0] === se) || {}).code : '';
  return Object.entries(SCH_CRST.v).reduce((a, [k, n]) => { const [s2, b2, y2] = k.split('|'); return a + (b2 === c && (!sc || s2 === sc) && !String(CR_BR_SKIPYR[c] || '').includes(y2) ? n : 0); }, 0); };
// 일정 장수: 크리스는 브랜드 줄 센터 확정 합(재고 파일 · 뺄 년도 반영 — 마스터 2026-11-19) · 재고 파일을 아직 못 읽었거나 없으면 넣은 장수
// 일정 추가에서 장수를 비웠을 때 자동 장수 (마스터 2026-11-20) — 분류만 · 없으면 0
function schAutoQ(br, kind, se) {
  if (kind !== '분류') return 0;
  if (br === '크리스') { const n = CR_BR_ROWS.reduce((a, [c]) => { const v = schCrStock(c, se); return v == null ? NaN : a + v; }, 0); return n > 0 ? n : 0; }
  const tg = (brSortAll().tgt || {})[br], had = (schCfg().extra || []).some(x => schExBrand(x) === br && schExKind(x) === '분류');
  return tg && +tg.total > 0 && !had ? +tg.total : 0;
}
// 밀레 등 다른 브랜드 분류 일정 =그 브랜드 분류 대상 파일 합계 (마스터 2026-11-20 · 밀레 셔츠 중분류 자료 113,202장 · 같은 브랜드 첫 분류 일정만)
const schExQ = e => { const q = +e.q || 0, br = schExBrand(e); if (!(q > 0)) return q;
  if (br && br !== '크리스') { const tg = (brSortAll().tgt || {})[br], first = (schCfg().extra || []).find(x => schExBrand(x) === br && schExKind(x) === '분류');
    return tg && +tg.total > 0 && schExKind(e) === '분류' && first && first.id === e.id ? +tg.total : q; }
  if (br !== '크리스') return q;
  const n = CR_BR_ROWS.reduce((a, [c]) => { const v = schCrStock(c, e.se); return v == null ? NaN : a + v; }, 0); return n > 0 ? n : q; };
// 브랜드 일정 기간: 분류를 시작했으면 첫 분류일부터 · 남은 장수(일정 장수 − 분류) ÷ 하루 장수만큼 뒤로 · 다 끝났으면 마지막 분류일까지
function schExRange(e, a, sp) {
  const br = schExBrand(e), G = schExG(e), q = schExQ(e), t = todayStr();
  if (!G || !G.done) return { a, b: scWorkEnd(a, Math.max(1, Math.ceil(q / sp))), G, br };
  const a2 = G.first < a ? G.first : a, rem = Math.max(0, q - G.done);
  if (rem < 1) return { a: a2, b: G.last, G, br };
  return { a: a2, b: scWorkEnd(scNextWork(G.last >= t ? scAdd(G.last, 1) : t), Math.ceil(rem / sp)), G, br };
}
const scAdd = (d, n) => { const t = new Date(d + 'T00:00:00'); t.setDate(t.getDate() + n); return `${t.getFullYear()}-${String(t.getMonth() + 1).padStart(2, '0')}-${String(t.getDate()).padStart(2, '0')}`; };
const scNextWork = d => { let x = d; for (let i = 0; i < 30 && !isWorkday(x); i++) x = scAdd(x, 1); return x; };
// 휴대폰은 칸이 좁아 짧게: 32,967 → 3.3만 · 티셔츠 → 티
const scMan = n => n >= 10000 ? (Math.round(n / 1000) / 10) + '만' : n >= 1000 ? (Math.round(n / 100) / 10) + '천' : String(Math.round(n));
const scTx = (full, short) => `<i class="lg">${full}</i><i class="sm">${short}</i>`;
const scMD = d => `${+d.slice(5, 7)}/${+d.slice(8)}(${'일월화수목금토'[new Date(d + 'T00:00:00').getDay()]})`;

// 시즌 일정표: 종류별 이름 (PC · 휴대폰)
const SP_K = { ord: ['반품지시', '지시'], ret: ['반품최종', '최종'], cfm: ['검수확정 마감', '확정'], avl: ['가용화 예정', '가용'],
  b2bo: ['B2B 주문입력', 'B2B'], b2b: ['B2B 출고', 'B2B'], mv: ['재고이관 완료', '이관'], wk: ['주간', '주'] };
const spPlan = () => (state.seasonPlan || {})[state.owner] || null;
const SP_SHOW = ['ret', 'b2b', 'mv'];   // 달력에는 반품 최종일 · 출고(B2B 출고) · 재고이관 완료만 (나머지는 칸이 너무 복잡해져서 뺌)
const spItems = () => { const P = spPlan(), c = state.center || DEFAULT_CENTER; return P ? (P.items || []).filter(x => x.c === c && SP_SHOW.includes(x.k)) : []; };
// 날짜 → 그날 보여 줄 일정 (매장반품은 기간 끝날(최종일) 하루만 — 쉬는 날이면 그 앞 작업일 · 주간 계획은 그 주 첫 작업일(달이 바뀌면 그 달 첫 작업일)에)
function spByDate(first, last) {
  const out = {}, put = (d, x) => { if (d >= first && d <= last) (out[d] = out[d] || []).push(x); };
  spItems().forEach(x => {
    if (x.k === 'ret') { let d = x.d2 || x.d; for (let i = 0; i < 7 && d > x.d && !isWorkday(d); i++) d = scAdd(d, -1); put(d, x); }
    else if (x.k === 'wk') { let d = x.d < first ? first : x.d; for (let i = 0; i < 7 && d <= x.d2 && !isWorkday(d); i++) d = scAdd(d, 1); if (d <= x.d2) put(d, x); }
    else put(x.d, x);
  });
  return out;
}
const spQ = q => q ? ' ' + scMan(q) : '';
function spTag(x) {
  const [k, ks] = SP_K[x.k] || [x.k, x.k];
  const full = x.k === 'wk' ? `${x.w} · ${x.t}${spQ(x.q)}` : x.k === 'ret' ? `${k} ${x.t}${spQ(x.q)}` : `${k} · ${x.t}`;
  const tip = [x.k === 'wk' ? `주간 계획 ${scMD(x.d)}~${scMD(x.d2)}` : k + (x.d2 ? ` ${scMD(x.d)}~${scMD(x.d2)}` : ''), x.t, x.o ? '차수 ' + x.o : '', x.rf || '', x.q ? '예상 ' + fmt(x.q) + '장' : ''].filter(Boolean).join(' · ');
  return `<span class="sc-i sc-sp k-${x.k}" title="${esc(tip)}">${scTx(esc(full), esc(ks))}</span>`;
}

// 워크노트 중요(📌) 글에 기간이 있으면 달력에: "11월 2일~6일" · "11/2~11/6" · "11월 28일~12월 3일" (기간만 · 날짜 하나는 안 함)
//  내용 = 기간이 적힌 줄에서 날짜를 뺀 글 (비면 첫 줄) · 연도는 글 쓴 날 기준 (쓴 날보다 반년 넘게 앞이면 다음 해)
const NP_RE = /(\d{1,2})\s*(?:월\s*|[/.])\s*(\d{1,2})\s*일?\s*[~∼～\-–]\s*(?:(\d{1,2})\s*(?:월\s*|[/.])\s*)?(\d{1,2})\s*일?/;
function notePeriods() {
  const out = [], p2 = n => String(n).padStart(2, '0');
  (typeof notes !== 'undefined' ? notes.list || [] : []).filter(n => n.pinned && !n.parent_id).forEach(n => {
    const t = noteText(n), lines = t.split('\n').map(x => x.trim()).filter(Boolean), c = new Date(n.created_at);
    lines.forEach(ln => {
      const m = ln.match(NP_RE); if (!m) return;
      const m1 = +m[1], d1 = +m[2], m2 = m[3] ? +m[3] : m1, d2 = +m[4];
      if (m1 < 1 || m1 > 12 || m2 < 1 || m2 > 12 || d1 < 1 || d1 > 31 || d2 < 1 || d2 > 31) return;
      let y = isNaN(c) ? +todayStr().slice(0, 4) : c.getFullYear();
      if (!isNaN(c) && new Date(y, m1 - 1, d1) < new Date(c.getFullYear(), c.getMonth() - 6, 1)) y++;
      const a = `${y}-${p2(m1)}-${p2(d1)}`, b = `${m2 < m1 ? y + 1 : y}-${p2(m2)}-${p2(d2)}`;
      if (b < a) return;
      const rest = ln.replace(m[0], '').replace(/^[\s,·:\-]+|[\s,·:\-]+$/g, ''), lab = [rest, ln === lines[0] ? '' : lines[0]].filter(Boolean).join(' · ') || lines[0];
      out.push({ id: n.id, a, b, lab, full: t });
    });
  });
  return out;
}
function npByDate(first, last) {
  const out = {};
  notePeriods().forEach(x => { for (let d = x.a < first ? first : x.a, i = 0; d <= x.b && d <= last && i < 62; d = scAdd(d, 1), i++) (out[d] = out[d] || []).push(x); });
  return out;
}
const npTag = x => `<span class="sc-i sc-np" data-gonote="${x.id}" title="${esc(`📌 ${scMD(x.a)}~${scMD(x.b)}\n${x.full}`)}">${scTx('📌 ' + esc(x.lab), '📌' + esc(x.lab.slice(0, 4)))}</span>`;

// 업무 스케줄러에서 쓰는 상품 시즌 — 네파 공지로 다른 시즌에 포함된 스타일은 그 시즌으로 (마스터 2026-11-16)
//  7MD0601: 품번은 공용 여름(D)이지만 공지 「봄 스타일에 포함」 · 봄 차수로 검수돼 센터 확정도 봄 → 분류(정리수량)도 봄 (엑셀 정리현황과 같게)
const SCH_SE_FIX = { NEPA: { '7MD0601': '봄' } };
const schSe = s => ((SCH_SE_FIX[state.owner] || {})[s]) || styleSeason(s);
// 소터 날짜 · 복종별 분류 장수 (파일은 누적 총량 → 그날 − 직전 작업일)
function schDaily() {
  const key = dataVer() + '|' + scopeKey() + '|' + state.sorter_result.length + '|' + state.year;
  if (sch.cache.dk === key) return sch.cache.daily;
  const out = sorterDeltaBy(sorterExcl(state.sorter_result), s => groupOf(s) || '기타');   // 포승 오입고분 뺌 (07-calc SORTER_EXCL) · 스타일마다 늘어난 만큼
  sch.cache.dk = key; sch.cache.daily = out;
  return out;
}
// 시즌 하나의 복종별 남은 장수 (대시보드 소터 칸과 같은 계산을 그 시즌으로)
function schRemain(se) {
  const key = [se, dataVer(), scopeKey(), state.sorter_result.length, state.return_insp.length, state.return_plan.length, state.year, JSON.stringify(state.settings.packQtyS || {})].join('|');
  const RK = sch.cache.remM = sch.cache.remM || new Map();   // 시즌마다 따로 기억 (예전: 한 시즌만 기억해 봄 · 여름 · 가을 · 겨울을 화면 그릴 때마다 다시 계산 → 대시보드 느림)
  if (RK.size > 40) RK.clear();
  if (RK.has(key)) return RK.get(key);
  const keep = { se: state.filter.season, sd: state.sortDate };
  let out = null;
  try {
    state.filter.season = se; state.sortDate = '';
    const ib = inboundCalc();
    if (ib && ib.hasTarget) {
      const c = state.return_plan.length ? { planQty: sum(state.return_plan.filter(passPlan), 'plan_qty') } : null, fl = c ? boxFlow() : null;   // calc()는 예정 장수만 쓰므로 그 합만 (calc 전체는 무거움)
      const before = c && fl ? Math.max(0, (c.planQty - fl.qty.반입) + fl.qty.미처리) : 0;   // 아직 검수 안 된 예정 장수 (대시보드 남은 예정수량)
      const tq = ib.grps.reduce((a, g) => a + g.tq, 0);
      out = { d: ib.d, before, grps: ib.grps.map(g => { const plus = tq ? before * g.tq / tq : 0; return { grp: g.grp, tq: g.tq, done: g.qty, left: Math.max(0, g.tq - g.qty), plus, rem: Math.max(0, g.tq - g.qty) }; }) };   // 남은 = 검수 끝난 잔량만 (예정을 비율로 나눈 추정치는 넣지 않음 — 마스터 2026-11-02 · plus는 박스 소요량에서만 씀)
    }
  } finally { state.filter.season = keep.se; state.sortDate = keep.sd; }
  RK.set(key, out);
  return out;
}
// 고른 시즌(전체 · S/S · F/W · 한 시즌)의 시즌 · 복종별 남은 장수 — 시즌마다 schRemain, 같은 복종이라도 시즌별로 따로 (티셔츠 (여름) · 티셔츠 (봄))
function schRemainSet(f) {
  const L = seasonPickList(f).map(se => [se, schRemain(se)]).filter(x => x[1]); if (!L.length) return null;
  return { d: L[0][1].d, before: L.reduce((a, x) => a + (x[1].before || 0), 0), grps: L.flatMap(([se, R]) => R.grps.map(g => Object.assign({}, g, { se, key: se + '|' + g.grp }))) };
}
const schLab = g => g.bulk ? g.se + ' 전체 (' + g.parts.map(grpName).join('·') + ')' : grpName(g.grp) + ' (' + g.se + ')';
// 위쪽 요약 줄 이름: 복종 + 작은 글씨 시즌 (한 줄 · 칸 맞춤) — 한 번에 분류는 「봄 전체 4복종」 (복종 목록은 마우스 올리면)
const schNm = g => g.bulk ? esc(g.se) + ' 전체<small>' + g.parts.length + '복종</small>' : esc(grpName(g.grp)) + '<small>' + esc(g.se) + '</small>';
const schShort = g => g.bulk ? g.se.charAt(0) : grpName(g.grp).charAt(0);
// 그 시즌만 한 날(그날 분류의 90% 이상) 최근 5일 평균 — 한 번에 분류하는 시즌의 실제 하루 장수 (분류를 시작하면 추정 대신 이 값)
function soloSe(se) {
  const byD = sorterDeltaBy(sorterExcl(state.sorter_result), s => schSe(s) || '미지정'), ds = Object.keys(byD).sort(), D = ds.map(d => byD[d]);
  const solo = D.filter(o => { const T = Object.values(o).reduce((a, v) => a + v, 0); return T > 0 && (o[se] || 0) / T >= SC_SOLO; }).slice(-SC_N);
  return solo.length ? { v: solo.reduce((a, o) => a + o[se], 0) / solo.length, how: `${se}만 한 날 ${solo.length}일 평균 (한 번에 분류)`, auto: true } : null;
}
// 한 번에 분류하는 시즌 (설정 bulk: { 시즌: 하루 장수(0 = 최근 5일 전체 평균) }) → 그 시즌 복종을 한 줄로 합침
function schBulk(grps, cfg, daily) {
  const B = cfg.bulk || {}, out = [], merged = {};
  grps.forEach(g => { if (!(g.se in B)) { out.push(g); return; }
    const o = merged[g.se] = merged[g.se] || { grp: '*', se: g.se, key: g.se + '|*', bulk: true, parts: [], tq: 0, done: 0, left: 0, plus: 0, rem: 0 };
    o.parts.push(g.grp); ['tq', 'done', 'left', 'plus', 'rem'].forEach(k => { o[k] += g[k] || 0; }); });
  Object.values(merged).forEach(o => { const man = +B[o.se] || 0, last = Object.values(daily).map(x => Object.values(x).reduce((a, v) => a + v, 0)).filter(Boolean).slice(-SC_N);
    o.sp = soloSe(o.se) || (man ? { v: man, how: '직접 넣은 값 (한 번에 분류)', man: true } : last.length ? { v: last.reduce((a, v) => a + v, 0) / last.length, how: `최근 ${last.length}일 전체 평균 (${esc(schAutoSeason() || '지금 분류')} 기준 추정 · 한 번에 분류)`, est: true } : { v: 0, how: '자료 없음' }); out.push(o); });
  return out;
}
// 지금 분류 중인 시즌 (마지막 소터 작업일에 가장 많이 분류한 상품 시즌)
function schAutoSeason() {
  const ds = [...new Set(state.sorter_result.map(r => r.work_date).filter(Boolean))].sort(), d = ds[ds.length - 1];
  if (!d) return '';
  const by = {}; sorterExcl(state.sorter_result).forEach(r => { if (r.work_date === d) { const s = schSe(r.style); if (SEASONS.includes(s)) by[s] = (by[s] || 0) + (r.qty || 0); } });
  return (Object.entries(by).sort((a, b) => b[1] - a[1])[0] || [''])[0];
}
// 복종별 하루 장수
function schSpeed(grp, daily, cfg) {
  const solo = Object.entries(daily).filter(([, o]) => { const T = Object.values(o).reduce((a, v) => a + v, 0); return T > 0 && (o[grp] || 0) / T >= SC_SOLO; }).slice(-SC_N);
  if (solo.length) return { v: solo.reduce((a, [, o]) => a + o[grp], 0) / solo.length, how: `${grp}만 한 날 ${solo.length}일 평균`, auto: true };
  const man = +((cfg.speed || {})[grp]) || 0;
  if (man) return { v: man, how: '직접 넣은 값', man: true };
  const last = Object.values(daily).map(o => Object.values(o).reduce((a, v) => a + v, 0)).filter(Boolean).slice(-SC_N);
  return last.length ? { v: last.reduce((a, v) => a + v, 0) / last.length, how: `최근 ${last.length}일 전체 평균(추정)`, est: true } : { v: 0, how: '자료 없음' };
}
function schPlan() {
  const cfg = schCfg(), se = seasonPickName(cfg.season || '');   // 시즌 선택창 공통 (처음 값 = 전체 · 시즌 · 복종별로 따로 계산)
  if (!schAutoSeason()) return null;   // 소터 자료 없음
  const R = schRemainSet(cfg.season || ''); if (!R) return { se, none: true };
  const daily = schDaily(), order = cfg.order || [];
  const lastD = Object.keys(daily).sort().pop() || '', t = todayStr();
  // 진행 순서: 설정한 순서(시즌|복종) → (설정 없으면) 지금 분류 중인 시즌 먼저 → 많이 끝낸 복종 먼저 (분류율 높은 순)
  const pct = g => g.done + g.rem ? g.done / (g.done + g.rem) : 0, auto = schAutoSeason(), seR = s => s === auto ? -1 : SEASONS.indexOf(s);
  const oi = g => { const i = order.indexOf(g.key); return i < 0 ? 99 : i; };
  const grps = schBulk(R.grps, cfg, daily).map(g => g.sp ? g : Object.assign(g, { sp: schSpeed(g.grp, daily, cfg) }))
    .sort((a, b) => oi(a) - oi(b) || seR(a.se) - seR(b.se) || pct(b) - pct(a) || a.rem - b.rem);
  grps.forEach((g, i) => { g.col = SC_COL[i % SC_COL.length]; });
  // 인원 조정 (마스터 2026-11-12: 일정 막대를 눌러 인원을 바꾸면 생산성 → 일정이 따라 바뀜): 하루 장수 × 넣은 인원 ÷ 기준 인원(최근 5일 평균 출근)
  //  → 2026-11-13 마스터: 1/n 아님 — 분류량은 인덕션(투입)이 정함 → 인덕션 배치로 계산 (schCrewAdj)
  const crew = cfg.crew || {}, bh = schBaseHeads();
  grps.forEach(g => { const n = +crew[g.se + '|*'], A = schCrewAdj(n, bh); if (A && g.sp && g.sp.v) g.sp = Object.assign({}, g.sp, { v: g.sp.v * A.f, base: g.sp.v, crew: n, how: `${g.sp.how} · 인원 ${n}명 (${A.txt})` }); });
  // 시작: 오늘 분류가 아직 안 올라왔으면 오늘부터, 올라왔으면 다음 작업일부터
  //  끼워 넣은 일정(일정 추가 · 날짜 지정)이 차지한 날은 건너뜀 → 진행 중인 일정이 그만큼 뒤로 (마스터 2026-11-12)
  const BL = schBlocked(), nextW = d => { let x = scNextWork(d); for (let i = 0; i < 200 && BL.has(x); i++) x = scNextWork(scAdd(x, 1)); return x; };
  let cur = nextW(lastD >= t ? scAdd(t, 1) : t), used = 0;
  const days = {};
  grps.forEach(g => {
    if (g.rem < 1 || !g.sp.v) return;
    let need = g.rem / g.sp.v;
    for (let i = 0; need > 1e-6 && i < 400; i++) {
      const take = Math.min(1 - used, need);
      (days[cur] = days[cur] || []).push({ grp: g.grp, lab: schLab(g), sl: schShort(g), q: take * g.sp.v, col: g.col });
      need -= take; used += take;
      if (need <= 1e-6) g.end = cur;
      if (used >= 1 - 1e-6) { cur = nextW(scAdd(cur, 1)); used = 0; }
    }
  });
  return { se, R, grps, days, lastD, start: Object.keys(days).sort()[0] || '' };
}

function renderHomeSched() {
  const box = $('homeSched'); if (!box) return;
  if (state.homeOpen) { box.innerHTML = ''; return; }
  const P = schPlan();
  sch.ex = [];
  const grid = (() => { try { return schGrid(P); } catch (er) { console.error(er); return `<div class="empty">정리현황 표를 그리지 못했습니다: ${esc(er.message)}</div>`; } })();   // 먼저 그려야 브랜드 일정 날짜(sch.ex)를 앎
  // 브랜드 일정 (크리스 · 밀레): 그 브랜드 소터 파일로 분류한 총수량 ÷ 일정 장수 (마스터 2026-11-16 · 시즌 · 복종 나누지 않음)
  const brSum = sch.ex.filter(x => x.br && +x.e.q > 0).map(x => { const q = schExQ(x.e), done = x.G ? x.G.done : 0, rem = Math.max(0, q - done), pc = Math.min(rem >= 1 ? 99 : 100, Math.floor(done / q * 100)), tg = (brSortAll().tgt || {})[x.br];
    const when = rem < 1 ? scMD(x.G.last) + ' 분류 끝' : done ? scMD(x.b) + ' 완료 예상' : scMD(x.a) + ' 시작 예정';
    return `<div class="sc-sum" style="--c:#15803D" title="${esc(`${x.br} 소터 분류 파일로 분류한 장수 ${fmt(done)} ÷ 일정 장수 ${fmt(q)} (시즌 · 복종 나누지 않고 총수량만)${tg ? ` · 분류 대상 파일 ${tg.file} ${fmt(tg.total)}장` : ''} · 하루 ${x.how}`)}"><b>${esc(x.e.nm)}<small>${esc(x.br)}</small></b><span class="sc-pct">${pc}%</span><span class="sc-when">${when}</span><span class="sc-bar"><i style="width:${pc}%"></i></span><em>분류 ${fmt(done)} / ${fmt(q)}장 · 남은 ${fmt(rem)}장 · 하루 ${fmt(Math.round(x.sp))}</em></div>`; }).join('');
  // 위쪽 요약: 복종별 끝나는 날
  const sum = (!P ? '' : brSum) + (!P ? '<span class="na">소터 분류 자료가 없습니다.</span>' : P.none ? `<span class="na">${esc(P.se)} 검수 자료가 없어 끝나는 날을 계산하지 못했습니다.</span>`
    : P.grps.filter(g => g.rem >= 1).map(g => { const pc = g.done + g.rem ? Math.min(99, Math.floor(g.done / (g.done + g.rem) * 100)) : 0; // 남은 게 있으면 100% 안 됨 (반올림 99.6→100 막음)
      return `<div class="sc-sum" style="--c:${g.col}" title="남은 ${fmt(Math.round(g.rem))}장 = 검수 완료 − 분류 (검수 전 예정은 넣지 않음) · 하루 ${fmt(Math.round(g.sp.v))}장 (${esc(g.sp.how)})"><b title="${esc(schLab(g))}">${schNm(g)}</b><span class="sc-pct">${pc}%</span><span class="sc-when">${(e => e ? scMD(e) + ' 종료 (잔여 있음)' : g.end ? scMD(g.end) + ' 완료 예상' : '하루 장수 없음')(schEnded(g))}</span><span class="sc-bar"><i style="width:${pc}%"></i></span><em>남은(검수분) ${fmt(Math.round(g.rem))}장 · 하루 ${fmt(Math.round(g.sp.v))}${g.sp.est ? ' (추정)' : g.sp.man ? ' (직접)' : ''}</em></div>`; }).join('')
      || (brSum ? '' : `<span class="na">${esc(P.se)} 분류할 잔량이 없습니다.</span>`));
  const cfg = schCfg();
  const set = schCan() && P && P.grps ? `<details class="sc-set" ${sch.open ? 'open' : ''}><summary>스케줄 설정</summary>
      <div class="row" style="gap:8px;align-items:center;margin:6px 0"><label>시즌 <select id="scSe">${seasonOpts(cfg.season || '')}</select></label>
        <label>정리현황 일 목표 <input type="number" id="scGoal" min="0" step="1000" value="${+cfg.goal || SG_GOAL}" style="width:90px">장</label>
        <span class="na">진행 순서는 ▲▼로 · 하루 장수는 그 복종만 한 날이 생기면 자동으로 바뀝니다 (그 전까지 직접 넣은 값 사용)</span></div>
      <div style="overflow-x:auto"><table class="ordtbl"><tr><th>순서</th><th>복종</th><th>남은 장수</th><th>하루 장수</th><th>직접 입력</th></tr>
      ${P.grps.map((g, i) => `<tr><td><button class="btn line sm" data-scmv="${esc(g.key)}" data-dir="-1" ${i ? '' : 'disabled'}>▲</button> <button class="btn line sm" data-scmv="${esc(g.key)}" data-dir="1" ${i < P.grps.length - 1 ? '' : 'disabled'}>▼</button></td>
        <td><b style="color:${g.col}">${esc(schLab(g))}</b></td><td>${fmt(Math.round(g.rem))}</td><td>${fmt(Math.round(g.sp.v))} <span class="na">${esc(g.sp.how)}</span></td>
        <td><input type="number" min="0" step="100" data-scsp="${esc(g.grp)}" value="${(cfg.speed || {})[g.grp] || ''}" placeholder="예) 22000" style="width:100px" ${g.bulk ? 'disabled title="한 번에 분류는 아래 시즌 칸에 넣으세요"' : ''}></td></tr>`).join('')}</table></div>
      <div class="row" style="gap:12px;align-items:center;margin-top:8px;flex-wrap:wrap"><b>한 번에 분류</b> <span class="na">체크한 시즌은 복종을 나누지 않고 한 줄로 · 하루 장수를 비우면 최근 5일 전체 평균</span>
        ${[...new Set(P.R.grps.map(g => g.se))].map(se => `<label style="display:flex;gap:4px;align-items:center"><input type="checkbox" data-scbulk="${esc(se)}" ${(cfg.bulk || {})[se] !== undefined ? 'checked' : ''}> ${esc(se)} 하루 <input type="number" min="0" step="1000" data-scbulkv="${esc(se)}" value="${+(cfg.bulk || {})[se] || ''}" placeholder="예) 30000" style="width:90px">장</label>`).join('')}</div>
      <button class="btn sm" id="btnScSave" style="margin-top:6px">설정 저장</button></details>` : '';
  const old = box.querySelector('.og-wrap'), sx = old && old.dataset.pos ? old.scrollLeft : null;   // 다시 그려도 옆으로 넘긴 위치 그대로 (아직 오늘로 맞춘 적 없으면 새로 맞춤)
  box.innerHTML = `<div class="box sc-box"><div class="sc-head"><h3>업무 스케줄러</h3>${P ? `<span class="tag">소터 분류 기간 예상${cfg.season ? ' · ' + esc(P.se) : ''}</span>` : ''}</div>
    <div class="sc-sums">${sum}</div>
    ${grid}
    ${set}</div>`;
  // 표 설명 (!) 아이콘은 「업무 스케줄러」 제목 옆에 (마스터 2026-11-12: 표 아래 왼쪽 구석에 있던 것)
  const nt = box.querySelector('.sc-note'), h3 = box.querySelector('.sc-head h3'); if (nt && h3) { const s = document.createElement('span'); s.className = 'na'; s.textContent = nt.textContent; h3.appendChild(s); nt.remove(); }
  const w = box.querySelector('.og-wrap');
  if (w && sx != null) { w.scrollLeft = sx; w.dataset.pos = '1'; } else schToToday(w);
}
// 처음엔 최근 5일(오늘 포함)부터 보이게 (마스터 2026-11-13) — 다른 메뉴를 보다 새로고침하면 대시보드가 숨은 채 그려져 위치를 못 잡음 → 보일 때(showPage) 다시 맞춤
function schToToday(w) {
  if (!w || !w.clientWidth) return;   // 숨어 있으면 위치 계산이 안 됨 → 대시보드가 보일 때 다시
  const th = w.querySelector('th.today');
  w.scrollLeft = th ? Math.max(0, th.offsetLeft - SG_LEFT - th.offsetWidth * 4) : w.scrollWidth;
  w.dataset.pos = '1';
}

/* ---------------- 정리현황 표 (달력 대신 — 마스터 2026-11-12: 「04. 2026년 반품 진행 현황.xlsx」 정리현황 시트 모양) ----------------
   줄 = TOTAL · 시즌별 복종 + 소계 · 투입 인원 · 1/n 생산성 / 열 = 작업일 (그날 분류 장수) · 맨 위 「소터 분류 일정」 줄 = 실제 · 예정 분류 기간 막대
   센터 확정수량 = 검수 완료 (업무 스케줄러와 같은 schRemain · 최종반품 포함) · 정리수량 = 날짜 칸 분류 장수 합 (엑셀과 같음 · 사계절 상품 제외) · 차이 = 확정 − 정리
   일정(일) = 확정 ÷ 일 목표 (설정 · 처음 30,000) · 시작일 = 실제 첫 분류일 (안 한 복종은 앞 줄 끝난 다음 작업일부터) · 종료일 = 시작일부터 일정만큼 작업일 (엑셀과 같음)
   시작~종료 칸 색칠 · 투입 인원 = 인원관리 출근부 · 1/n 생산성 = 그날 분류 ÷ 인원 */
const SG_GOAL = 30000, SG_LEFT = 536, SG_W = 76;   // SG_W = 날짜 칸 너비 (css .og th · td 와 같게 · 막대 위치 계산)   // SG_LEFT = 왼쪽 고정 칸 너비 합 (css .og)
const scWorkEnd = (d, n) => { let x = scNextWork(d); for (let i = 1; i < n; i++) x = scNextWork(scAdd(x, 1)); return x; };
const sgMD = d => `${+d.slice(5, 7)}/${+d.slice(8)}`;
// 시즌 · 복종별 실제 소터 분류 기간 [{ a, b }] — 그 복종이 그날 분류의 10% 이상인 날을 이음 (작업일 3일까지 비어도 이어짐)
//  그 복종 분류 합의 5% 안 되는 짧은 기간은 뺌 (마스터 2026-11-12: 여름은 11/10에 끝 — 11/11 최종반품 조금 분류는 일정이 아님)
function schRuns() {
  const key = [dataVer(), scopeKey(), state.year, state.sorter_result.length].join('|');
  if (sch.cache.ruK === key) return sch.cache.ru;
  const daily = sorterDeltaBy(sorterExcl(state.sorter_result), s => (schSe(s) || '미지정') + '|' + (groupOf(s) || '기타'));
  const ds = Object.keys(daily).sort(), last = ds[ds.length - 1] || '', cols = [], keys = new Set(), runs = {};
  for (let d = ds[0], i = 0; d && d <= last && i < 400; d = scAdd(d, 1), i++) if (isWorkday(d) || daily[d]) cols.push(d);
  const dayT = d => Object.values(daily[d] || {}).reduce((a, v) => a + v, 0);
  ds.forEach(d => Object.keys(daily[d]).forEach(k => keys.add(k)));
  keys.forEach(k => { const L = []; let cur = null, gap = 0, tot = 0;
    cols.forEach(d => { const q = (daily[d] || {})[k] || 0, T0 = dayT(d); tot += q;
      if (q > 0 && T0 && q / T0 >= 0.1) { if (cur && gap <= 3) cur.b = d; else { cur = { a: d, b: d }; L.push(cur); } gap = 0; }
      else if (cur && isWorkday(d)) gap++; });
    runs[k] = L.filter(x => cols.filter(d => d >= x.a && d <= x.b).reduce((a, d) => a + ((daily[d] || {})[k] || 0), 0) >= tot * 0.05); });
  sch.cache.ruK = key; sch.cache.ru = { runs, last, daily, ds };
  return sch.cache.ru;
}
// 분류가 끝난 복종: 실제 기간의 끝날이 마지막 소터 작업일보다 앞 (다른 복종 · 시즌으로 넘어감) → 그 끝날 (마스터 2026-11-12: 「11/2 종료 (잔여 있음)」)
// 기준 인원 = 최근 소터 작업일 5일(출근부 있는 날)의 평균 출근 인원 — 인원 조정의 기준 (출근부 없으면 0 → 조정 못 함)
function schBaseHeads() {
  if (typeof prodHeads !== 'function') return 0;
  const t = todayStr(), H = prodHeads(scAdd(t, -60), t), D = schDaily();
  const L = Object.keys(H).filter(d => D[d] && Object.values(D[d]).some(v => v > 0)).sort().slice(-5);
  return L.length ? L.reduce((a, d) => a + H[d], 0) / L.length : 0;
}
const schEnded = g => { if (g.bulk) return ''; const U = schRuns(), L = U.runs[g.se + '|' + g.grp] || [], b = L.length ? L[L.length - 1].b : ''; return b && b < U.last ? b : ''; };
// 일정 추가의 하루 평균 (마스터 2026-11-12): 그 시즌 · 복종이 그날 분류의 절반 이상인 날의 평균 → 없으면 같은 복종 다른 시즌 → 전체 하루 평균(분류 합 ÷ 분류한 날)
//  (여러 복종을 같이 한 날은 그 복종 장수가 작게 나와 빼고 셈 — 봄 자켓 하루 5,705장은 아님)
function schAllAvg() { const U = schRuns(), T = U.ds.map(d => Object.values(U.daily[d]).reduce((a, v) => a + v, 0)).filter(v => v > 0); return T.length ? T.reduce((a, v) => a + v, 0) / T.length : SG_GOAL; }
// 시즌 생산성 (마스터 2026-11-13: 일정 추가는 고른 시즌의 생산성을 씀) = 생산성 탭 「○ 합계」 줄의 하루 평균(실제) · 올해 자료
//  생산성 자료는 처음 한 번 불러와 기억 (생산성 탭 보는 연도 · 시즌 고른 값은 건드리지 않음)
function schProdLoad() {
  if (sch.pdS || sch.pdBusy || typeof prodCalc !== 'function' || !DB.isRemote()) return;
  sch.pdBusy = true; const y = String(new Date().getFullYear()), from = y + '-01-01', to = y + '-12-31';
  invRpc('inv_prod_daily', { p_owner: scopeKey(), p_from: from, p_to: to }).then(rows => {
    const keep = { rows: pd.rows, heads: pd.heads, se: pd.se };
    try { pd.rows = (rows || []).filter(r => r[1] === PD_KIND); pd.heads = prodHeads(from, to); pd.se = '';
      const C = prodCalc(), o = {}; C.ses.forEach(se => { const s = C.sRow(se); if (s && s.day) o[se] = s; }); sch.pdS = o; }
    finally { Object.assign(pd, keep); }
    sch.pdBusy = false; renderHomeSched();
  }).catch(() => { sch.pdBusy = false; sch.pdS = {}; });   // 못 불러오면(권한 등) 예전 계산 그대로
}
function schProdSe(se) { if (!se) return null; schProdLoad(); const s = (sch.pdS || {})[se]; return s ? { v: s.day, how: `${se} 시즌 생산성 (하루 평균 · ${s.days}일)` } : null; }
function schSpOf(e) {
  const P = schProdSe(e.se); if (P) return P;
  const U = schRuns(), dTot = d => Object.values(U.daily[d] || {}).reduce((a, v) => a + v, 0);
  const avgOf = (se, grp) => { let q = 0, n = 0; Object.keys(U.runs).forEach(k => { const [s, g] = k.split('|'); if ((se && s !== se) || (grp && g !== grp)) return;
    U.ds.forEach(d => { const v = (U.daily[d] || {})[k] || 0, T0 = dTot(d); if (v && T0 && v / T0 >= 0.5) { q += v; n++; } }); }); return n ? q / n : 0; };
  if (!e.se && !e.grp) return { v: schAllAvg(), how: '전체 평균' };
  let v = avgOf(e.se, e.grp); if (v) return { v, how: [e.se, e.grp ? grpName(e.grp) : ''].filter(Boolean).join(' ') + ' 평균' };
  if (e.grp && e.se && (v = avgOf('', e.grp))) return { v, how: grpName(e.grp) + ' 다른 시즌 평균' };
  return { v: schAllAvg(), how: '전체 평균' };
}
// 인원 → 인덕션 배치 (마스터 2026-11-13: 분류량은 인덕션이 정함 · 인덕션 4대 × 메인 1 + 서브 1 = 8명 · 서브 없으면 그 인덕션 50% (11/13 현장관리직 의견 · 처음엔 75%) · 4대일 때 뒤쪽 최소 10명)
//  뒤쪽 최소 인원 = 인덕션 대수별 자리 (마스터 2026-11-13): 제품 공급 · 박스 공급 · 라인 · 정리
//   4대 1·1·6·2 = 10 · 3대 1·1·5·2 = 9 · 2대 1·1·4·1 = 7 · 1대 1·1·3·1 = 6 (1대는 라인 줄어드는 대로 이은 값)
//  넣은 인원으로 가장 많이 분류하는 배치를 고름 · 18명 이상 = 4대 · 서브 4 · 뒤쪽 10 → 100% (더 넣어도 인덕션이 막혀 늘지 않음 — 출근부 24일: 인원 −20%에 분류 −11%)
const SC_IND = 4, SC_NOSUB = 0.5, SC_BACK = { 1: [1, 1, 3, 1], 2: [1, 1, 4, 1], 3: [1, 1, 5, 2], 4: [1, 1, 6, 2] };
const scBackN = s => SC_BACK[s].reduce((a, v) => a + v, 0);
function schCrewPlan(n) {
  let best = { r: 0, s: 0, k: 0, back: 0, need: 0 };
  for (let s = 1; s <= SC_IND; s++) for (let k = 0; k <= s; k++) { const back = scBackN(s), need = s + k + back, r = (k + (s - k) * SC_NOSUB) / SC_IND;
    if (need <= n && (r > best.r + 1e-9 || (Math.abs(r - best.r) < 1e-9 && need < best.need))) best = { r, s, k, back, need }; }
  return best;
}
const SC_FULL = SC_IND * 2 + scBackN(SC_IND);   // 18명
const SC_MIN = 1 + scBackN(1);   // 인덕션 1대 최소 7명
// 하루 장수에 곱할 값 = 넣은 인원 배치 ÷ 기준 인원 배치 (기준 인원 = 최근 5일 평균 출근)
function schCrewAdj(n, bh) {
  if (!(n > 0) || !bh) return null; const P = schCrewPlan(n), B = schCrewPlan(Math.round(bh)); if (!P.r || !B.r) return null;
  return { f: P.r / B.r, P, txt: `인덕션 ${P.s}대 · 서브 ${P.k}명 · 뒤쪽 ${P.back}명(제품 ${SC_BACK[P.s][0]} · 박스 ${SC_BACK[P.s][1]} · 라인 ${SC_BACK[P.s][2]} · 정리 ${SC_BACK[P.s][3]})${n > P.need ? ` · 여유 ${n - P.need}명` : ''} → ${Math.round(P.r * 100)}%`, warn: n < SC_FULL ? `${SC_FULL}명 미만 — 인덕션을 다 못 돌려 분류가 줄어듭니다` : '' };
}
// 일정 추가 하루 장수 (인원 조정 반영: 인덕션 배치)
function schExSp(e) { const S = schSpOf(e), n = +((schCfg().crew || {})['x|' + e.id]), A = schCrewAdj(n, schBaseHeads()); return A ? { v: S.v * A.f, base: S.v, how: S.how + ` · 인원 ${n}명 (${A.txt})` } : { v: S.v, base: S.v, how: S.how }; }
// 끼워 넣은 일정 (일정 추가 막대를 진행 중인 막대 가운데로 끌어 놓음 → e.at = 시작일 · 마스터 2026-11-12)
//  그 기간 작업일은 진행 중인 일정이 건너뜀 (봄 전체 3일 → 크리스 → 봄 나머지)
function schInterrupts() {
  const cfg = schCfg(), BE = cfg.barEnd || {}; let free = '';
  return (cfg.extra || []).filter(e => e.at).sort((x, y) => x.at.localeCompare(y.at)).map(e => { const S = schExSp(e), key = 'x|' + e.id;
    let a = scNextWork(e.at); if (free && a < free) a = free;
    const RG = schExRange(e, a, S.v); a = RG.a; let b = RG.b; if (BE[key] && BE[key] >= a) b = BE[key]; free = scNextWork(scAdd(b, 1));   // 브랜드 일정은 분류한 만큼 뺀 남은 장수로
    const days = new Set(); for (let d = a, i = 0; d <= b && i < 200; d = scAdd(d, 1), i++) if (isWorkday(d)) days.add(d);
    return { e, a, b, sp: S.v, base: S.base, how: S.how, days }; });
}
const schBlocked = () => { const s = new Set(); schInterrupts().forEach(x => x.days.forEach(d => s.add(d))); return s; };
function schGrid(P) {
  const R = schRemainSet(''); if (!R) return '';
  const cfg = schCfg(), goal = +cfg.goal || SG_GOAL, t = todayStr();
  const daily = sorterDeltaBy(sorterExcl(state.sorter_result), s => (schSe(s) || '미지정') + '|' + (groupOf(s) || '기타'));
  const ds = Object.keys(daily).sort(), firstOf = k => ds.find(d => (daily[d][k] || 0) > 0) || '';
  const bySe = {};
  R.grps.filter(g => g.tq >= 1).forEach(g => (bySe[g.se] = bySe[g.se] || []).push({ se: g.se, grp: g.grp, k: g.se + '|' + g.grp, tq: g.tq, done: ds.reduce((a, d) => a + (daily[d][g.se + '|' + g.grp] || 0), 0), first: firstOf(g.se + '|' + g.grp) }));
  const seL = Object.keys(bySe).map(se => ({ se, f: bySe[se].map(r => r.first).filter(Boolean).sort()[0] || '9' }))
    .sort((a, b) => a.f.localeCompare(b.f) || SEASONS.indexOf(a.se) - SEASONS.indexOf(b.se)).map(x => x.se);
  if (!seL.length) return '';
  let free = scNextWork(t);   // 아직 시작 안 한 복종은 앞 줄이 끝난 다음 작업일부터 (오늘 이후)
  const tot = L => ({ tq: L.reduce((a, r) => a + r.tq, 0), done: L.reduce((a, r) => a + r.done, 0), days: L.reduce((a, r) => a + r.days, 0),
    start: L.map(r => r.start).sort()[0], end: L.map(r => r.end).sort().pop(), keys: L.flatMap(r => r.keys || [r.k]) });
  const blocks = seL.map((se, i) => {
    // 복종 순서 = 엑셀 정리현황과 같게 티셔츠 · 바지 · 자켓 · 다운 (마스터 2026-11-16) · 그 밖의 복종은 뒤에 (분류 시작 순)
    const SG_ORD = ['TS', '바지', 'PT', 'JK', '다운'], gOrd = g => { const i = SG_ORD.indexOf(String(g).toUpperCase()); return i < 0 ? 99 : i; };
    const rows = bySe[se].sort((a, b) => gOrd(a.grp) - gOrd(b.grp) || (a.first || '9').localeCompare(b.first || '9') || b.tq - a.tq);
    rows.forEach(r => { r.days = r.tq / goal; r.start = r.first || free; r.end = scWorkEnd(r.start, Math.max(1, Math.ceil(r.days))); if (r.end >= free) free = scNextWork(scAdd(r.end, 1)); });
    return { se, col: SC_COL[i % SC_COL.length], rows, sub: tot(rows) };
  });
  let T = tot(blocks.map(b => b.sub));
  const qOf = (d, keys) => keys.reduce((a, k) => a + ((daily[d] || {})[k] || 0), 0);
  // 맨 위 「소터 분류 일정」 줄 (마스터 2026-11-12: 소터 분류 일정만 · 시작~끝 막대 · 잘 보이게)
  //  실제(진한 막대): 복종이 그날 분류의 10% 이상인 날을 이어 붙임 (작업일 3일까지 비어도 이어짐) → 같은 시즌에서 기간이 겹치면 한 막대 「여름 티셔츠·자켓 10/8~11/2」
  //  지금 분류 중(끝나지 않음)이면 막대를 위 진행 막대의 완료 예상일까지 늘림 · 한 번에 분류하는 시즌은 「봄 전체 11/11~11/19」 (마스터 2026-11-12)
  //  막대 오른쪽 끝을 끌면 끝나는 날을 직접 바꿈 (cfg.barEnd[막대 키] · 끝을 두 번 누르면 원래대로)
  const RU = schRuns().runs, PB = P && P.grps ? P.grps : [], bars = [], BE = cfg.barEnd || {};
  blocks.forEach(b => {
    const runs = b.rows.flatMap(r => { const L = (RU[r.k] || []).map(x => ({ a: x.a, b: x.b, g: [r.grp] })), pg = PB.find(g => !g.bulk && g.se === b.se && g.grp === r.grp);
      if (L.length && pg && pg.rem >= 1 && pg.end && !schEnded(pg) && pg.end > L[L.length - 1].b) L[L.length - 1].b = pg.end;
      return L; });
    const M = []; runs.sort((x, y) => x.a.localeCompare(y.a)).forEach(x => { const m = M[M.length - 1];
      if (m && x.a <= m.b) { if (x.b > m.b) m.b = x.b; x.g.forEach(g => { if (!m.g.includes(g)) m.g.push(g); }); } else M.push({ a: x.a, b: x.b, g: x.g.slice() }); });
    const bk = PB.find(g => g.bulk && g.se === b.se);
    if (bk && M.length) { const m = M[M.length - 1]; if (bk.end && bk.end > m.b) m.b = bk.end; m.bulk = true; m.col = bk.col; }
    // 아직 남은 분류가 있는 시즌의 마지막 막대 = 인원 조정 가능 (ck = 시즌|*)
    const live = PB.filter(g => g.se === b.se && g.rem >= 1 && g.end && !schEnded(g)), lp = bk || live[0];
    const BL = schBlocked();
    M.forEach((m, j) => { const key = b.se + '|' + m.a;
      // 끝을 끌어 정한 날(barEnd)이 있어도, 그 안에 끼워 넣은 일정이 차지한 날 수만큼 끝을 뒤로 밂 (마스터 2026-11-12: 크리스 11/18 시작 → 봄 하루가 11/23으로)
      if (BE[key] && BE[key] >= m.a) { let e = BE[key], n = 0; for (let d = m.a, i = 0; d <= e && i < 400; d = scAdd(d, 1), i++) if (BL.has(d)) n++;
        for (let i = 0; n > 0 && i < 400; i++) { e = scNextWork(scAdd(e, 1)); if (!BL.has(e)) n--; } m.b = e; }
      const ck = schCan() && j === M.length - 1 && lp && m.b >= t ? b.se + '|*' : '';
      const base = { se: b.se, key, ck, live: !!(j === M.length - 1 && lp && m.b >= t), sp: ck ? lp.sp.v : 0, base: ck ? (lp.sp.base || lp.sp.v) : 0, col: m.col || b.col, g: m.g, bulk: !!m.bulk, nm: m.bulk ? `${b.se} 전체` : `${b.se} ${m.g.map(grpName).join('·')}` };
      // 끼워 넣은 일정이 지나가는 날에서 막대를 끊음 (봄 전체 11/11~11/13 · 크리스 · 봄 전체 11/19~)
      const seg = []; let s = null;
      for (let d = m.a, i = 0; d <= m.b && i < 400; d = scAdd(d, 1), i++) { if (BL.has(d)) { s = null; continue; } if (!isWorkday(d) && !daily[d]) continue; if (!s) { s = { a: d, b: d }; seg.push(s); } else s.b = d; }
      (seg.length ? seg : [{ a: m.a, b: m.b }]).forEach(g => bars.push(Object.assign({}, base, { a: g.a, b: g.b }))); });
  });
  // 표 시작일 · 종료일 = 위 「소터 분류 일정」 막대 날짜 그대로 (마스터 2026-11-19: 봄 전체 11/11~11/18이면 표도 11/11~11/18) · 막대 없는 복종만 계산값
  blocks.forEach(b => { b.rows.forEach(r => { const L = bars.filter(x => x.se === b.se && (x.bulk || (x.g || []).includes(r.grp)))   // 「봄 전체」 막대면 그 시즌 모든 복종;
    if (L.length) { r.start = L.map(x => x.a).sort()[0]; r.end = L.map(x => x.b).sort().pop(); } }); b.sub = tot(b.rows); });
  T = tot(blocks.map(b => b.sub));
  // 일정 추가 (마스터 2026-11-12: 「봄 전체 다음 크리스 ○장」): 장수 ÷ 하루 평균(schSpOf · 인원 조정 반영) → 마지막 막대 다음 작업일부터 차례로
  //  끼워 넣은 일정(e.at)은 그 날짜부터 (schInterrupts) — 진행 중인 막대는 위에서 그 날들을 건너뛰어 나뉨
  const allAvg = schAllAvg(), IT = schInterrupts(), bh = schBaseHeads();
  let xfree = scNextWork([scAdd(bars.concat(IT).map(x => x.b).sort().pop() || t, 1), t].sort().pop());
  const exKind = schExKind;
  const exLab = e =>[e.se, e.grp ? grpName(e.grp) : ''].filter(Boolean).join(' ');
  // 막대 이름: 일정 추가에서 브랜드를 고른 일정(e.br)이고 이름이 브랜드와 다르면 「네파 (봄) 출고」 (마스터 2026-11-19) · 그 밖은 예전처럼 「크리스 (봄 자켓)」
  const exNm = (e, lab) => { const b = e.br || '', n = e.nm || b; return !('br' in e) || !b || n === b || n.startsWith(b) ? n + (lab ? ` (${lab})` : '') : `${b}${lab ? ` (${lab})` : ''} ${n}`; };
  const extras = (cfg.extra || []).map(e => { const key = 'x|' + e.id, it = IT.find(x => x.e.id === e.id); let a, b, S;
    if (it) { a = it.a; b = it.b; S = { v: it.sp, base: it.base, how: it.how }; }
    else { S = schExSp(e); const RG = schExRange(e, xfree, S.v); a = RG.a; b = RG.b; if (BE[key] && BE[key] >= a) b = BE[key]; xfree = scNextWork(scAdd(b, 1)); }
    const lab = exLab(e);
    bars.push({ key, ck: schCan() ? key : '', sp: S.v, base: S.base, a, b, col: '#15803D', nm: exNm(e, lab), exId: e.id, q: schExQ(e), lab, how: S.how + (it ? ` · ${sgMD(a)}에 끼워 넣음` : '') });   // exId · q · how = 막대 눌렀을 때 창에 보임 (마스터 2026-11-12: 아래 목록 대신)
    const br = schExBrand(e), G = schExG(e);   // 브랜드 소터 분류 (총수량만) · 출고 일정은 분류 장수를 안 씀 · 크리스는 그 시즌만
    return { e, br, G, sp: S.v, how: S.how + (it ? ` · ${sgMD(a)}에 끼워 넣음` : ''), days: schExQ(e) / S.v, a, b, lab }; }).sort((x, y) => x.a.localeCompare(y.a));
  sch.ex = extras;   // 위쪽 요약 줄의 브랜드 진행률 (renderHomeSched)
  bars.forEach(x => { x.dt = x.a === x.b ? sgMD(x.a) : sgMD(x.a) + '~' + sgMD(x.b); });
  // 일정마다 다른 색 (마스터 2026-11-16: 소터 분류 일정에 다른 일정이면 색상 다르게) — 앞 일정부터 원래 색을 쓰되, 이미 쓴 색이면 안 쓴 색으로
  { const PAL = ['#0E7490', '#15803D', '#B45309', '#7C3AED', '#BE185D', '#4D7C0F', '#9A3412', '#0369A1', '#334155'], used = new Set(), byNm = {};
    bars.slice().sort((x, y) => x.a.localeCompare(y.a)).forEach(x => { if (!byNm[x.nm]) { const c = !used.has(x.col) ? x.col : (PAL.find(p => !used.has(p)) || x.col); used.add(c); byNm[x.nm] = c; } x.col = byNm[x.nm]; });
    blocks.forEach(b => { const L = bars.filter(x => x.se === b.se).pop(); if (L) b.col = L.col; });   // 시즌 줄 색 = 그 시즌 막대 색
  }
  // 날짜 칸: 첫 분류일 ~ (가장 늦은 종료일 · 오늘 · 3월 말) 작업일 + 쉬는 날이라도 분류한 날
  const mar = `${+t.slice(5, 7) >= 4 ? +t.slice(0, 4) + 1 : t.slice(0, 4)}-03-31`;   // 날짜 칸은 3월 말까지 (마스터 2026-11-12)
  const first = T.start, last = [T.end, t, mar].concat(bars.map(x => x.b)).sort().pop(), cols = [];
  for (let d = first, i = 0; d <= last && i < 400; d = scAdd(d, 1), i++) if (isWorkday(d) || daily[d]) cols.push(d);
  const W = SG_W, LH = 24, ci = d => { const i = cols.findIndex(x => x >= d); return i < 0 ? cols.length - 1 : i; };
  // 한 줄(두께 = 글자 두 줄)에 그림: 안 겹치는 막대는 두 줄 두께(이름 / 기간) · 기간이 겹치는 곳은 위 · 아래 반씩 나눠 글자가 안 가려지게 (마스터 2026-11-12)
  const tw = s => [...s].reduce((a, c) => a + (c.charCodeAt(0) > 255 ? 14 : 8), 0) + 14;
  // 막대 한 줄 그리기 (소터 분류 일정 · 반품 일정 같은 양식) — edit = 끝 끌기 · 인원 조정 가능 여부
  const laneRow = (title, L, edit, fit) => { const lanes = [];   // fit = 막대를 날짜 칸 너비에 딱 맞춤 (글자 작게 · 줄바꿈 — 기타 일정)
    L.forEach(x => { const i0 = ci(x.a), i1 = Math.max(i0, ci(x.b)); x.L = i0 * W + 1; x.sw = (i1 - i0 + 1) * W - 3; });   // 겹침은 실제 기간(sw)으로만 판단
    L.sort((x, y) => x.L - y.L)
      .forEach(x => { let k = lanes.findIndex(e => e <= x.L + 2); if (k < 0) { k = lanes.length; lanes.push(0); } lanes[k] = x.L + x.sw; x.lane = k; });
    L.forEach(x => { x.solo = !L.some(y => y !== x && y.L < x.L + x.sw && x.L < y.L + y.sw); x.one = !x.solo || tw(x.nm + '  ' + x.dt) <= x.sw; x.w = Math.max(x.sw, x.one ? tw(x.nm + '  ' + x.dt) : Math.max(tw(x.nm), tw(x.dt))); if (fit) { x.w = x.sw; x.one = false; } x.sh = Math.min(Math.round((x.w - x.sw) / 2), x.L - 1); x.dl = x.L - x.sh; });   // 글자가 칸보다 길면 날짜 칸 가운데에 오게 양쪽으로 넘침 (마스터 2026-11-12)   // 막대 안에 한 줄로 들어가면 한 줄 · 아니면 두 줄 (가운데 정렬)
    const nL = Math.max(2, lanes.length), rzH = '<span class="og-rz" title="끌어서 끝나는 날 바꾸기 · 두 번 누르면 원래대로"></span>';
    const rzOf = x => !schCan() ? '' : /^[mr]\|/.test(x.key || '') ? '<span class="og-rz" title="끌어서 끝나는 날 바꾸기"></span>' : (edit || /^n\|/.test(x.key || '')) ? rzH : '';   // 기타 · 반품/출고 일정도 끝 끌기 (마스터 2026-11-13)
    const cls = x => (x.ck ? ' ck' : '') + (x.ck && x.ck === sch.crewOpen ? ' on' : ''), att = x => `data-key="${esc(x.key || '')}" data-ck="${esc(x.ck || '')}" data-sh="${x.sh || 0}"${x.tip ? ` title="${esc(x.tip)}"` : ''}`;
    return `<tr class="ev"><th class="s1" colspan="10">${title}</th><td colspan="${cols.length}"><div class="og-lanes" data-cols="${cols.join(',')}" style="width:${cols.length * W}px;height:${nL * LH + 8}px">${L.map(x => x.solo
      ? `<span class="og-bar${x.one ? '' : ' two'}${fit ? ' fit' : ''}${cls(x)}" ${att(x)} style="--c:${x.col};left:${x.dl}px;top:4px;width:${x.w}px;height:${nL * LH}px"><b>${esc(x.nm)}</b>${x.dt ? `<i>${esc(x.dt)}</i>` : ''}${rzOf(x)}</span>`
      : `<span class="og-bar${fit ? ' fit' : ''}${cls(x)}" ${att(x)} style="--c:${x.col};left:${x.dl}px;top:${x.lane * LH + 4}px;width:${x.w}px;height:${LH - 2}px">${esc(x.dt ? x.nm + '  ' + x.dt : x.nm)}${rzOf(x)}</span>`).join('')}</div></td></tr>`; };
  // 반품 일정 (마스터 2026-11-12: 소터 분류 일정 위에 같은 양식 · 공지사항 「26년 S/S 시즌 반품 일정 안내」의 매장 반품 기간)
  //  = 시즌 일정표(seasonPlan) 이 센터의 매장반품 기간(ret) · 3091 최종잔량은 공지에 없으면 11/9~11/13 (마스터 2026-11-12)
  //  표 첫 날짜보다 먼저 끝난 차수는 안 그림 · 먼저 시작한 차수는 첫 칸부터 (기간 글자는 실제 날짜)
  const RT = spItems().filter(x => x.k === 'ret');
  if (!RT.some(x => String(x.o).includes('3091'))) RT.push({ k: 'ret', o: '3091', d: '2026-11-09', d2: '2026-11-13', t: '봄,여름 의류 최종잔량' });
  const seCol = se => (blocks.find(b => b.se === se) || {}).col || (/최종반품/.test(se) ? '#BE185D' : '#6B7280');
  // 공지 반품 일정도 끌어서 옮기기 · 끝 늘이기 (마스터 2026-11-13) — cfg.retMove { '차수@공지 시작일': { a, b } } · 끝을 두 번 누르면 공지 날짜로
  const RM = cfg.retMove || {};
  const rbars = RT.map(x => { const nk = String(x.o) + '@' + x.d, mv = RM[nk]; return mv && mv.a ? Object.assign({}, x, { nk, d: mv.a, d2: mv.b && mv.b > mv.a ? mv.b : mv.a }) : Object.assign({}, x, { nk }); })
    .filter(x => (x.d2 || x.d) >= cols[0]).map(x => { const b2 = x.d2 || x.d, o = String(x.o || '').split('·')[0];
    return { key: 'n|' + x.nk, a: x.d < cols[0] ? cols[0] : x.d, b: b2, col: seCol(seasonOf(o)), nm: `${x.o} ${String(x.t || '').replace(/\s*_\s*/g, ' ')}`.trim(), dt: x.d === b2 ? sgMD(x.d) : sgMD(x.d) + '~' + sgMD(b2), tip: `${x.o} ${x.t} 매장 반품 ${sgMD(x.d)}~${sgMD(b2)}${x.q ? ' · 예상 ' + fmt(+x.q) + '장' : ''} (공지사항 반품 일정)` }; });
  // 직접 넣은 반품 일정 (마스터 2026-11-12: 반품 일정 추가) — cfg.retAdd [{ id, nm, a, b }] · 끌어서 날짜 옮김
  (cfg.retAdd || []).filter(x => (x.b || x.a) >= cols[0] && x.a <= cols[cols.length - 1]).forEach(x => { const b2 = x.b && x.b > x.a ? x.b : x.a;
    rbars.push({ key: 'r|' + x.id, a: x.a < cols[0] ? cols[0] : x.a, b: b2, col: '#9D174D', nm: x.nm, dt: x.a === b2 ? sgMD(x.a) : sgMD(x.a) + '~' + sgMD(b2), tip: `${x.nm} ${sgMD(x.a)}~${sgMD(b2)} (직접 넣은 반품/출고 일정 · 끌어서 옮김)` }); });
  const topRow = laneRow('반품/출고 일정', rbars, false) + laneRow('소터 작업 일정', bars, true)   /* 「작업 일정」 → 「소터 작업 일정」 (마스터 2026-11-19) */;
  // 기타 일정 (마스터 2026-11-12: 1/n 생산성 아래 · 예 「11/12 크리스 박스 입고」) — cfg.memo [{ id, nm, a, b }] · 표 날짜 밖은 안 그림
  const mbars = (cfg.memo || []).filter(x => (x.b || x.a) >= cols[0] && x.a <= cols[cols.length - 1]).map(x => { const b2 = x.b && x.b > x.a ? x.b : x.a;
    return { key: 'm|' + x.id, a: x.a < cols[0] ? cols[0] : x.a, b: b2, col: '#B45309', nm: x.nm, dt: '', tip: `${x.nm} ${x.a === b2 ? sgMD(x.a) : sgMD(x.a) + '~' + sgMD(b2)}` }; });   // 날짜는 막대에 안 씀 (마스터 2026-11-12 · 마우스 올리면 보임)
  const memoRow = laneRow('기타 일정', mbars, false, true);
  sch.bars = { ret: rbars, sort: bars, memo: mbars };   // 업무일지 보고서 「다음 일정」이 같은 막대를 씀 (24-journal jrqHtml)
  const heads = typeof prodHeads === 'function' ? prodHeads(first, last) : {};
  const num = v => v ? fmt(Math.round(v)) : '';
  const cells = (o, sub) => cols.map(d => `<td class="${d >= o.start && d <= o.end ? 'on' : ''}${d === t ? ' today' : ''}${sub ? ' sub' : ''}">${num(qOf(d, o.keys || [o.k]))}</td>`).join('');
  const left = (o, sub) => `<td class="s3">${o.days.toFixed(1)}</td><td class="s4">${sgMD(o.start)}</td><td class="s5">${sgMD(o.end)}</td><td class="s6">${fmt(Math.round(o.tq))}</td><td class="s7">${fmt(Math.round(o.done))}</td><td class="s8${o.tq - o.done < 0 ? ' neg' : ''}">${fmt(Math.round(o.tq - o.done))}</td>`;
  // 맨 왼쪽 브랜드 칸 (마스터 2026-11-19) · 크리스는 네파처럼 시즌 · 복종으로 나눔 (크리스는 자켓뿐) — 나머지 추가 일정은 「추가」 묶음
  const SG_SPLIT = ['크리스'], XQ = extras.filter(x => +x.e.q > 0);
  const exCol = x => (bars.find(y => y.exId === x.e.id) || {}).col || '#15803D';
  // 추가 일정 브랜드 칸 = 브랜드마다 고정 색 (마스터 2026-11-19): 네파 = 위 네파 칸과 같은 파랑 · 밀레 = 분홍 · 그 밖 = 막대 색
  const exBrSty = (br, x) => br === '네파' ? 'background:#C7D2FE;color:#0F2A5C' : `--c:${{ 밀레: '#BE185D' }[br] || exCol(x)}`;
  const exLeft = x =>left({ days: x.days, start: x.a, end: x.b, tq: schExQ(x.e), done: x.G ? x.G.done : 0 });
  const exCells = x => cols.map(d => `<td class="${d >= x.a && d <= x.b ? 'on' : ''}${d === t ? ' today' : ''}">${x.G ? num(x.G.day[d]) : ''}</td>`).join('');
  const exTip = x => esc(x.e.nm + (x.lab ? ' · ' + x.lab : '') + ' · 하루 ' + fmt(Math.round(x.sp)) + '장 기준');
  const XS = XQ.filter(x => SG_SPLIT.includes(x.br)), XR = XQ.filter(x => !XS.includes(x));
  // 1/n 생산성 장수 = 네파 분류 + 다른 브랜드(크리스 · 밀레 등) 분류 그날 장수 (마스터 2026-11-19: 크리스만 분류한 날도 나오게 · 브랜드마다 한 번만 더함)
  const exBG = [...new Set(XQ.filter(x => x.G).map(x => x.br))].map(b => brandSorted(b));   // 출고 일정은 빼고
  const allQ = d => qOf(d, T.keys) + exBG.reduce((a, G) => a + (+G.day[d] || 0), 0);
  const nepaN = 1 + blocks.reduce((a, b) => a + b.rows.length + 1, 0);
  const body = [`<tr class="tot" style="--c:#0F2A5C"><th class="s0 se br" rowspan="${nepaN}">네파</th><th class="s1" colspan="3">TOTAL</th>${left(T)}${cells(T, 1)}</tr>`]
    .concat(blocks.flatMap(b => b.rows.map((r, j) => `<tr style="--c:${b.col}">${j ? '' : `<th class="s1 se" rowspan="${b.rows.length + 1}">${esc(b.se)}</th><th class="sk se" rowspan="${b.rows.length + 1}">분류</th>`}<td class="s2">${esc(grpName(r.grp))}</td>${left(r)}${cells(r)}</tr>`)
      .concat(`<tr class="sub" style="--c:${b.col}"><td class="s2"><b>소계</b></td>${left(b.sub)}${cells(b.sub, 1)}</tr>`)))
    // 크리스 줄: 브랜드 | 시즌 | 복종 (TOTAL에는 안 넣음 · 날짜 칸 = 크리스 소터 분류 장수)
    // 크리스는 브랜드(품번 첫 자리)별 줄 + 소계 (마스터 2026-11-19 · 소계 = 크리스 일정 숫자 그대로 · 브랜드 줄은 정리수량 · 날짜 칸만)
    .concat(XS.flatMap(x => { const B = brandSortedBy(x.br, s => String(s)[0], schExSf(x.br, x.e)), n = CR_BR_ROWS.length + 1;
      // 브랜드 일정 (마스터 2026-11-19: 우리 생산성 기준) = 센터 확정 ÷ 크리스 일정 하루 장수 · 분류한 브랜드는 실제 첫 분류일부터
      //  남은 장수는 이 순서대로 이어 붙임 — 소계 막대처럼 마지막 분류일 다음 작업일(오늘 이후)부터 → 끝나는 날이 소계와 맞음
      const sp = x.sp || 1, r0 = x.G && x.G.done ? scNextWork(x.G.last >= t ? scAdd(x.G.last, 1) : t) : x.a, wd = i => scWorkEnd(r0, i + 1); let cum = 0;
      return CR_BR_ROWS.map(([c, nm, en], j) => { const o = B[c] || { done: 0, day: {} }, tq = schCrStock(c, x.e.se), dd = Object.keys(o.day).sort(), rem = Math.max(0, (tq || 0) - o.done), c0 = cum; cum += rem / sp;
        const bs = dd[0] || (rem >= 1 ? wd(Math.floor(c0)) : ''), be = rem >= 1 ? wd(Math.max(Math.floor(c0), Math.ceil(cum) - 1)) : (dd[dd.length - 1] || '');
        return `<tr class="${j ? '' : 'brs'}" style="--c:${exCol(x)}"><th class="s0 se br crg" title="${esc(c + ' ' + en)}">${esc(nm)}</th>${j ? '' : `<th class="s1 se" rowspan="${n}" title="${exTip(x)}">${esc(x.e.se || '전체')}</th><th class="sk se" rowspan="${n}">${exKind(x.e)}</th>`}<td class="s2">${esc(x.e.grp ? grpName(x.e.grp) : '')}</td><td class="s3">${tq ? (tq / sp).toFixed(1) : ''}</td><td class="s4">${bs ? sgMD(bs) : ''}</td><td class="s5">${be ? sgMD(be) : ''}</td><td class="s6">${tq ? fmt(tq) : ''}</td><td class="s7">${o.done ? fmt(o.done) : ''}</td><td class="s8${tq != null && tq - o.done < 0 ? ' neg' : ''}">${tq ? fmt(tq - o.done) : ''}</td>${cols.map(d => `<td class="${bs && d >= bs && d <= be ? 'on' : ''}${d === t ? ' today' : ''}">${num(o.day[d])}</td>`).join('')}</tr>`; })
        .concat(`<tr class="sub" style="--c:${exCol(x)}"><th class="s0 se br">${esc(x.br)}</th><td class="s2"><b>소계</b></td>${exLeft(x)}${exCells(x).replace(/<td class="/g, '<td class="sub ')}</tr>`); }))
    // 추가한 일정 줄 (TOTAL에는 안 넣음 · 아직 분류 안 한 계획)
    // 브랜드 | 시즌 | 복종 = 일정 추가에서 고른 그대로 (마스터 2026-11-19: 밀레 여름 티셔츠) · 복종 안 골랐으면 「전체」 (이름은 복종 칸에 안 넣음)
    // 추가 일정마다 소계 줄도 처음부터 (마스터 2026-11-19 · 네파 · 크리스 소계와 같은 모양: 브랜드 · 시즌 칸이 소계 줄까지 이어지고 「소계」는 복종 칸)
    .concat(XR.flatMap(x => [`<tr class="brs" style="--c:${exCol(x)}"><th class="s0 se br crg" rowspan="2" style="${exBrSty(x.br || '네파', x)}">${esc(x.br || '네파')}</th><th class="s1 se" rowspan="2">${esc(x.e.se || '전체')}</th><th class="sk se" rowspan="2">${exKind(x.e)}</th><td class="s2" title="${exTip(x)}">${esc(x.e.grp ? grpName(x.e.grp) : '전체')}</td>${exLeft(x)}${exCells(x)}</tr>`,
      `<tr class="sub" style="--c:${exCol(x)}"><td class="s2"><b>소계</b></td>${exLeft(x)}${exCells(x).replace(/<td class="/g, '<td class="sub ')}</tr>`]))
    .concat(`<tr class="ft"><th class="s1" colspan="10">투입 인원 <span class="og-r">${fmt(cols.reduce((a, d) => a + (heads[d] || 0), 0))}</span></th>${cols.map(d => `<td class="${d === t ? 'today' : ''}">${heads[d] || ''}</td>`).join('')}</tr>`,
      `<tr class="ft"><th class="s1" colspan="10">1/n 생산성 <span class="og-r">${(() => { const D = cols.filter(d => heads[d] && allQ(d) > 0); const h = D.reduce((a, d) => a + heads[d], 0); return h ? fmt(Math.round(D.reduce((a, d) => a + allQ(d), 0) / h)) : ''; })()}</span></th>${cols.map(d => `<td class="${d === t ? 'today' : ''}">${heads[d] && allQ(d) ? fmt(Math.round(allQ(d) / heads[d])) : ''}</td>`).join('')}</tr>`, memoRow);
  const wdN = d => '일월화수목금토'[new Date(d + 'T00:00:00').getDay()];
  return `
    <div class="og-wrap"><table class="og"><thead>
      ${topRow}
      <tr class="hd"><th class="s0">브랜드</th><th class="s1">시즌</th><th class="sk">구분</th><th class="s2">복종</th><th class="s3">일정<small>(일)</small></th><th class="s4">시작일</th><th class="s5">종료일</th><th class="s6">센터 확정</th><th class="s7">정리수량</th><th class="s8">차이</th>${cols.map(d => `<th class="${d === t ? 'today' : ''}${isWorkday(d) ? '' : ' off'}">${sgMD(d)}<small>${wdN(d)}</small></th>`).join('')}</tr>
    </thead><tbody>${body.join('')}</tbody></table></div>
    ${(cb => !cb ? '' : `<div class="og-crew" style="--c:${cb.col}"><b class="og-cn">${esc(cb.nm)}</b> <span>${esc(cb.dt)}</span>${cb.exId ? ` <label><input type="number" id="ogExQ" data-ex="${esc(cb.exId)}" min="0" step="1000" value="${+cb.q || 0}" style="width:100px"> 장</label>` : ''}
      ${bh ? `<label>인원 <input type="number" id="ogCrew" data-ck="${esc(cb.ck)}" min="${SC_MIN}" step="1" value="${+(cfg.crew || {})[cb.ck] || Math.round(bh)}" style="width:70px"> 명</label>` : ''}   <!-- 인원 칸은 장수 칸 바로 옆 (마스터 2026-11-16) -->
      ${bh ? `${(A => `<span title="${esc([cb.exId ? cb.how : '', `기준 인원 ${bh.toFixed(1)}명(최근 5일 평균 출근) · 기준 하루 ${fmt(Math.round(cb.base))}장`, A ? A.txt : ''].filter(Boolean).join(' · '))}">${esc(cb.lab || cb.nm)} · 하루 <b>${fmt(Math.round(cb.sp))}</b>장 · 끝나는 날 <b>${sgMD(cb.b)}</b></span>${A && A.warn ? `<b style="color:#DC2626">${esc(A.warn)}</b>` : ''}`)(schCrewAdj(+(cfg.crew || {})[cb.ck], bh))}   <!-- 짧게: 시즌·복종 · 하루 · 끝나는 날만 (마스터 2026-11-17) · 계산 근거는 마우스 올리면 -->

      ${(cfg.crew || {})[cb.ck] ? `<button class="btn line sm" data-crewreset="${esc(cb.ck)}">기준 인원으로</button>` : ''}`
      : '<span>인원관리 출근부 자료가 없어 인원으로 조정할 수 없습니다.</span>'}
      ${cb.exId ? `<button class="btn line sm og-del" data-ogdel="${esc(cb.exId)}">삭제</button>` : ''}<button class="btn line sm" data-crewclose>닫기</button></div>`)(sch.crewOpen && bars.find(x => x.ck === sch.crewOpen))}
    ${(k => { const m = /^([mr])\|(.+)$/.exec(k || ''); if (!m) return ''; const LK = m[1] === 'm' ? 'memo' : 'retAdd', x = (cfg[LK] || []).find(y => y.id === m[2]); if (!x) return '';   // 기타 · 반품 일정 막대 누르기 → 삭제 창 (마스터 2026-11-12)
      return `<div class="og-crew" style="--c:${m[1] === 'm' ? '#B45309' : '#9D174D'}"><b class="og-cn">${esc(x.nm)}</b> <span>${m[1] === 'm' ? '기타 일정' : '반품/출고 일정'} · ${sgMD(x.a)}${x.b && x.b !== x.a ? '~' + sgMD(x.b) : ''}</span>
      ${schCan() ? `<button class="btn line sm og-del" data-og${m[1]}del="${esc(x.id)}">삭제</button>` : ''}<button class="btn line sm" data-crewclose>닫기</button></div>`; })(sch.crewOpen)}
    ${schCan() ? `<div class="og-add"><b>일정 추가</b>
      <label>브랜드 <select id="ogBr"><option value="">네파</option>${brNames().map(b => `<option>${esc(b)}</option>`).join('')}</select></label>
      <label>구분 <select id="ogKd"><option>분류</option><option>출고</option></select></label><input id="ogQ" type="number" min="0" step="1000" placeholder="장수 (비우면 자동)" style="width:130px">
      <label>시즌 <select id="ogSe"><option value="">전체</option>${SEASONS.map(s => `<option>${s}</option>`).join('')}</select></label>
      <label>복종 <select id="ogGrp"><option value="">전체</option>${[...new Set(R.grps.map(g => g.grp))].map(g => `<option value="${esc(g)}">${esc(grpName(g))}</option>`).join('')}</select></label>
      <button class="btn sm" id="btnOgAdd">추가</button><span class="og-avg" id="ogAvg">전체 하루 평균 <b>${fmt(Math.round(allAvg))}</b>장</span></div>
    <div class="og-add"><b>반품/출고 일정 추가</b>
      <input id="ogRa" type="date" value="${t}"> ~ <input id="ogRb" type="date" title="하루면 비워 두세요"><input id="ogRn" placeholder="내용 (예: 3092 최종잔량)" style="width:200px">
      <button class="btn sm" id="btnOgRet">추가</button></div>
    <div class="og-add"><b>기타 일정 추가</b>
      <input id="ogMa" type="date" value="${t}"> ~ <input id="ogMb" type="date" title="하루면 비워 두세요"><input id="ogMn" placeholder="내용 (예: 크리스 박스 입고)" style="width:200px">
      <button class="btn sm" id="btnOgMemo">추가</button></div>` : ''}
    <div class="na sc-note">정리현황 표: 센터 확정 = 검수 완료 장수 · 정리수량 = 날짜 칸 분류 장수 합 (엑셀과 같음 · 사계절 상품 제외) · 차이 = 확정 − 정리. 일정(일) = 확정 ÷ 일 목표 · 시작일 = 실제 첫 분류일(아직 안 한 복종은 앞 줄 끝난 다음 작업일) · 종료일 = 시작일부터 일정만큼 작업일 → 그 사이 칸을 색칠. 날짜 칸 숫자 = 그날 분류 장수 · 투입 인원 = 인원관리 출근부 · 1/n 생산성 = 그날 분류 ÷ 인원. 맨 위 소터 분류 일정: 진한 막대 = 실제로 분류한 기간(복종이 그날 분류의 10% 이상인 날, 작업일 3일까지 비어도 이어 봄 · 같은 시즌에서 겹치면 한 막대). 막대 오른쪽 끝을 끌면 끝나는 날을 바꿉니다(두 번 누르면 원래대로). 추가한 일정 막대는 끌어서 자리를 바꿀 수 있습니다(놓은 순서대로 날짜 다시 계산). 진행 중인 막대(봄 전체 등) 안으로 막대 시작을 끌어 놓으면(하루만 당겨도) 그 날짜에 끼워 넣어 진행 중인 일정이 끊기고 나머지는 뒤로 밀립니다(밖으로 다시 끌면 풀림). 일정 추가: 장수 ÷ 하루 평균(고른 시즌 · 복종이 실제로 분류한 기간의 하루 평균, 안 고르면 전체 하루 평균) → 마지막 막대 다음 작업일부터 차례로. 추가 일정은 TOTAL에 넣지 않습니다. 반품/출고 일정: 공지사항 반품 일정(시즌 일정표)의 차수별 매장 반품 기간 (표 첫 날짜 전에 끝난 차수는 뺌). 남은 일이 있는 막대를 누르면 인원 조정란: 하루 장수 = 기준 하루 장수 × 넣은 인원 ÷ 기준 인원(최근 소터 작업일 5일 평균 출근) → 끝나는 날과 뒤 일정이 바로 다시 계산됩니다.</div>`;
}
function bindSched() {
  $('homeSched').addEventListener('click', async e => {
    const gn = e.target.closest('[data-gonote]'); if (gn) { goNote(+gn.dataset.gonote); return; }   // 📌 중요 체크리스트 기간 → 워크노트 그 글
    // 일정 막대 누르기 → 인원 조정란 열기 · 닫기 (끌어서 넘긴 뒤 손을 뗀 것은 누른 것으로 안 봄)
    if (e.target.closest('.og-rz')) return;
    const ckb = e.target.closest('.og-bar.ck');
    if (ckb) { if (sch.dragMoved) { sch.dragMoved = false; return; } sch.crewOpen = sch.crewOpen === ckb.dataset.ck ? '' : ckb.dataset.ck; renderHomeSched(); return; }
    const mrb = schCan() && e.target.closest('.og-bar[data-key^="m|"], .og-bar[data-key^="r|"]');   // 기타 · 반품 일정 막대 → 삭제 창 열기 · 닫기
    if (mrb) { if (sch.dragMoved) { sch.dragMoved = false; return; } sch.crewOpen = sch.crewOpen === mrb.dataset.key ? '' : mrb.dataset.key; renderHomeSched(); return; }
    if (e.target.closest('[data-crewclose]')) { sch.crewOpen = ''; renderHomeSched(); return; }
    const crs = e.target.closest('[data-crewreset]');
    if (crs) { const c = Object.assign({}, schCfg().crew || {}); delete c[crs.dataset.crewreset]; schPut({ crew: c }); renderHomeSched();
      try { await schSave(); toast('기준 인원으로 돌렸습니다.'); } catch (er) { toast('저장하지 못했습니다.\n' + er.message, 'err'); } return; }
    // 정리현황 표 일정 추가 · 지우기 (마스터 2026-11-12)
    // 기타 일정 넣기 · 지우기 (관리직 이상)
    // 기타 일정 · 반품 일정 직접 넣기 (마스터 2026-11-12)
    const addK = { btnOgMemo: ['memo', 'ogM', '기타 일정'], btnOgRet: ['retAdd', 'ogR', '반품/출고 일정'] }[e.target.id];
    if (addK) { const [LK, p, lb] = addK;
      const a = $(p + 'a').value, b = $(p + 'b').value, nm = ($(p + 'n').value || '').trim();
      if (!a || !nm) { toast('날짜와 내용을 넣어 주세요.', 'err'); return; }
      if (b && b < a) { toast('끝 날짜가 시작 날짜보다 앞입니다.', 'err'); return; }
      schPut({ [LK]: (schCfg()[LK] || []).concat({ id: Date.now().toString(36), nm, a, b: b || '' }) }); renderHomeSched();
      try { await schSave(); toast(`${lb} 「${nm}」을 넣었습니다.`); } catch (er) { toast('저장하지 못했습니다.\n' + er.message, 'err'); } return; }
    const md = e.target.closest('[data-ogmdel], [data-ogrdel]');
    if (md) { const LK = md.dataset.ogrdel ? 'retAdd' : 'memo', id = md.dataset.ogrdel || md.dataset.ogmdel, it = (schCfg()[LK] || []).find(x => x.id === id);
      if (!confirm(`「${it ? it.nm : ''}」 일정을 지울까요?`)) return; sch.crewOpen = ''; schPut({ [LK]: (schCfg()[LK] || []).filter(x => x.id !== id) }); renderHomeSched();
      try { await schSave(); } catch (er) { toast('저장하지 못했습니다.\n' + er.message, 'err'); } return; }
    if (e.target.id === 'btnOgAdd') {
      // 이름 칸 없앰 (마스터 2026-11-19) → 이름 = 브랜드 · 출고면 「출고」 (막대 「네파 (봄) 출고」)
      const br = $('ogBr') ? $('ogBr').value : '', brS = br || '네파', kind = $('ogKd').value === '출고' ? '출고' : '분류', nm = kind === '출고' ? '출고' : brS, qs = String($('ogQ').value || '').trim();
      // 장수를 비우면 자료에서 자동 (마스터 2026-11-20): 크리스 = 재고 파일(그 시즌) · 밀레 등 = 분류 대상 파일 합계
      const q = qs === '' ? schAutoQ(brS, kind, $('ogSe').value) : Math.round(+qs);
      if (qs === '' && !q) { toast('불러올 자료가 없습니다 — 장수를 넣어 주세요.', 'err'); return; }
      if (!(q >= 0)) { toast('장수를 넣어 주세요. (장수 0 = 소터 작업 일정 막대만 · 아래 표 줄엔 안 나옴)', 'err'); return; }   // 장수 0 허용 (마스터 2026-11-13: 최종반품처럼 수량이 봄·여름에 이미 들어간 일정)
      schPut({ extra: (schCfg().extra || []).concat({ id: Date.now().toString(36), nm, q, se: $('ogSe').value, grp: $('ogGrp').value, br: brS, kind }) }); renderHomeSched();
      try { await schSave(); toast(`「${nm}」 일정을 넣었습니다.`); } catch (er) { toast('저장하지 못했습니다.\n' + er.message, 'err'); } return; }
    const od = e.target.closest('[data-ogdel]');
    if (od) { const c = schCfg(), be = Object.assign({}, c.barEnd || {}), it = (c.extra || []).find(x => x.id === od.dataset.ogdel); delete be['x|' + od.dataset.ogdel];
      if (!confirm(`「${it ? it.nm : ''}」 일정을 지울까요?`)) return; sch.crewOpen = '';
      schPut({ extra: (c.extra || []).filter(x => x.id !== od.dataset.ogdel), barEnd: be }); renderHomeSched();
      try { await schSave(); } catch (er) { toast('저장하지 못했습니다.\n' + er.message, 'err'); } return; }
    const mv = e.target.closest('[data-scmv]');
    if (mv) { const P = schPlan(), list = P.grps.map(g => g.key), i = list.indexOf(mv.dataset.scmv), j = i + +mv.dataset.dir;
      if (j < 0 || j >= list.length) return; [list[i], list[j]] = [list[j], list[i]]; schPut({ order: list }); renderHomeSched();
      try { await schSave(); } catch (er) { toast('순서를 저장하지 못했습니다.\n' + er.message, 'err'); } return; }
    if (e.target.id === 'btnScSave') {
      const speed = {}; document.querySelectorAll('[data-scsp]').forEach(x => { if (+x.value) speed[x.dataset.scsp] = +x.value; });
      const bulk = {}; document.querySelectorAll('[data-scbulk]').forEach(x => { if (x.checked) { const v = document.querySelector(`[data-scbulkv="${x.dataset.scbulk}"]`); bulk[x.dataset.scbulk] = +(v && v.value) || 0; } });
      schPut({ speed, bulk, season: $('scSe').value, goal: +($('scGoal') || {}).value || SG_GOAL });
      try { await schSave(); toast('스케줄 설정을 저장했습니다.'); } catch (er) { toast('저장하지 못했습니다.\n' + er.message, 'err'); }
      renderHomeSched();
    }
  });
  $('homeSched').addEventListener('toggle', e => { if (e.target.classList.contains('sc-set')) sch.open = e.target.open; }, true);
  // 정리현황 표: 마우스로 끌어서 옆으로 넘기기 (마스터 2026-11-12)
  let drag = null, rzg = null, mvb = null;
  // 기타(m|) · 직접 넣은 반품/출고(r|) · 공지 반품(n|) 일정 날짜 바꾸기 — 옮기기 · 끝 늘이기 공통 (마스터 2026-11-13)
  //  a = null 이면 공지 반품 일정을 공지 날짜로 되돌림
  const setRange = async (key, a, b, msg) => { const kt = key.charAt(0), id = key.slice(2);
    if (kt === 'n') { const RM = Object.assign({}, schCfg().retMove || {}); if (a == null) delete RM[id]; else RM[id] = { a, b: b && b > a ? b : '' }; schPut({ retMove: RM }); }
    else { const LK = kt === 'm' ? 'memo' : 'retAdd', L = (schCfg()[LK] || []).map(x => Object.assign({}, x)), me = L.find(x => x.id === id); if (!me) { renderHomeSched(); return; }
      me.a = a; me.b = b && b > a ? b : ''; schPut({ [LK]: L }); }
    renderHomeSched();
    try { await schSave(); toast(msg); } catch (er) { toast('저장하지 못했습니다.\n' + er.message, 'err'); } };
  const curBar = key => ((sch.bars || {}).ret || []).concat((sch.bars || {}).memo || []).find(x => x.key === key);
  // 추가한 일정 막대를 끌어서 자리 바꾸기 (마스터 2026-11-12) — 놓은 위치(막대 가운데) 순서대로 일정 추가 목록을 다시 정렬 → 날짜 다시 계산
  //  실제로 한 · 하고 있는 막대(여름 · 봄 전체 등)는 기록이라 고정 · 조금만 움직이고 놓으면 누른 것(인원 조정란)으로 봄
  $('homeSched').addEventListener('mousedown', e => { if (e.button !== 0 || e.target.closest('.og-rz') || !schCan()) return;
    const bar = e.target.closest('.og-bar[data-key^="x|"], .og-bar[data-key^="m|"], .og-bar[data-key^="r|"], .og-bar[data-key^="n|"]'); if (!bar) return;
    mvb = { bar, x: e.clientX, L: bar.offsetLeft, moved: false, k: (bar.getBoundingClientRect().width / bar.offsetWidth) || 1 }; /* k = 화면 비율(맞춤 확대 · 축소) — 마우스 이동을 막대 이동으로 맞춤 */ e.stopPropagation(); e.preventDefault(); }, true);
  document.addEventListener('mousemove', e => { if (!mvb) return; const dx = (e.clientX - mvb.x) / mvb.k; if (Math.abs(dx) > 5) mvb.moved = true;
    if (mvb.moved) { mvb.bar.style.left = (mvb.L + dx) + 'px'; mvb.bar.classList.add('mv'); } });
  document.addEventListener('mouseup', async () => { if (!mvb) return; const m = mvb; mvb = null; if (!m.moved) return; sch.dragMoved = true; setTimeout(() => { sch.dragMoved = false; }, 0);
    const ln = m.bar.parentElement, myId = m.bar.dataset.key.slice(2), cols = ln.dataset.cols.split(','), c = m.bar.offsetLeft + m.bar.offsetWidth / 2;
    // 기타 일정 막대: 놓은 칸으로 날짜 옮김 (기간 길이(날짜 칸 수)는 그대로 · 마스터 2026-11-12)
    // 기타 일정(m|) · 직접 넣은 반품 일정(r|) 공통
    //  공지 반품 일정(n|)도 같이 (마스터 2026-11-13)
    if (/^[mrn]\|/.test(m.bar.dataset.key)) { const cur = curBar(m.bar.dataset.key); if (!cur) { renderHomeSched(); return; }
      const i0 = Math.min(cols.length - 1, Math.max(0, Math.round((m.bar.offsetLeft + (+m.bar.dataset.sh || 0) - 1) / SG_W))), oa = cols.indexOf(cur.a), ob = cols.indexOf(cur.b), span = oa >= 0 && ob >= oa ? ob - oa : 0;
      const a = cols[i0], b = span ? cols[Math.min(cols.length - 1, i0 + span)] : '';
      await setRange(m.bar.dataset.key, a, b, `「${cur.nm}」을 ${sgMD(a)}${b ? '~' + sgMD(b) : ''}로 옮겼습니다.`); return; }
    // 진행 중인 막대(봄 전체 등) 가운데에 놓으면 → 그 날짜에 끼워 넣기 (e.at) · 그 밖에 놓으면 끼워 넣기 풀고 순서만 바꿈
    const tl = m.bar.offsetLeft + (+m.bar.dataset.sh || 0), s0 = tl + 2, host = [...ln.querySelectorAll('.og-bar[data-ck$="|*"]')].find(b => s0 >= b.offsetLeft && s0 < b.offsetLeft + b.offsetWidth);   // 막대 시작(왼쪽 끝)이 진행 중인 막대 안에 들어가면 끼워 넣기 — 하루만 당겨도 됨
    const ex = (schCfg().extra || []).map(x => Object.assign({}, x)), me = ex.find(x => x.id === myId); if (!me) { renderHomeSched(); return; }
    let msg;
    if (host) { const at = cols[Math.min(cols.length - 1, Math.max(0, Math.round(tl / SG_W)))]; me.at = at; msg = `${sgMD(at)}부터 「${me.nm}」을 끼워 넣었습니다. 진행 중인 일정은 그만큼 뒤로 밀립니다.`; }
    else { const had = !!me.at; delete me.at; msg = had ? `「${me.nm}」 끼워 넣기를 풀었습니다.` : '일정 순서를 바꿨습니다.'; }
    const ids = [...ln.querySelectorAll('.og-bar[data-key^="x|"]')].map(b => ({ id: b.dataset.key.slice(2), c: b.offsetLeft + b.offsetWidth / 2 })).sort((a, b) => a.c - b.c).map(x => x.id);
    const next = ids.map(id => ex.find(x => x.id === id)).filter(Boolean).concat(ex.filter(x => !ids.includes(x.id)));
    schPut({ extra: next }); renderHomeSched();
    try { await schSave(); toast(msg); } catch (er) { toast('저장하지 못했습니다.\n' + er.message, 'err'); } });
  // 막대 오른쪽 끝 끌기 → 끝나는 날 바꿈 (칸 단위로 맞춤) · 두 번 누르면 원래대로
  $('homeSched').addEventListener('mousedown', e => { const h = e.target.closest('.og-rz'); if (!h || e.button !== 0) return;
    const bar = h.parentElement, ln = bar.parentElement; rzg = { bar, key: bar.dataset.key, cols: ln.dataset.cols.split(','), x: e.clientX, w0: bar.offsetWidth, L: bar.offsetLeft, sh: +bar.dataset.sh || 0, k: (bar.getBoundingClientRect().width / bar.offsetWidth) || 1 };
    e.preventDefault(); e.stopPropagation(); }, true);
  document.addEventListener('mousemove', e => { if (!rzg) return; rzg.w = Math.max(55, rzg.w0 + (e.clientX - rzg.x) / rzg.k); rzg.bar.style.width = rzg.w + 'px'; });
  document.addEventListener('mouseup', async () => { if (!rzg) return; const r = rzg; rzg = null; if (r.w == null) return;
    const i = Math.min(r.cols.length - 1, Math.max(0, Math.round((r.L + r.w - r.sh + 3) / SG_W) - 1)), d = r.cols[i];
    if (/^[mrn]\|/.test(r.key)) { const cur = curBar(r.key); if (!cur) { renderHomeSched(); return; }   // 기타 · 반품/출고 일정: 그 일정의 끝 날짜를 바꿈 (시작보다 앞이면 하루짜리)
      const b = d > cur.a ? d : ''; await setRange(r.key, cur.a, b, `「${cur.nm}」 기간을 ${sgMD(cur.a)}${b ? '~' + sgMD(b) : ''}로 바꿨습니다.`); return; }
    schPut({ barEnd: Object.assign({}, schCfg().barEnd || {}, { [r.key]: d }) }); renderHomeSched();
    try { await schSave(); toast(`끝나는 날을 ${sgMD(d)}로 바꿨습니다.`); } catch (er) { toast('저장하지 못했습니다.\n' + er.message, 'err'); } });
  $('homeSched').addEventListener('dblclick', async e => { const h = e.target.closest('.og-rz'); if (!h) return;
    const hk = h.parentElement.dataset.key || '';
    if (hk.startsWith('n|')) { await setRange(hk, null, null, '공지사항 날짜로 되돌렸습니다.'); return; }   // 공지 반품 일정 → 공지 날짜로
    if (/^[mr]\|/.test(hk)) return;   // 직접 넣은 일정은 되돌릴 원래 날짜가 없음
    const be = Object.assign({}, schCfg().barEnd || {}); delete be[h.parentElement.dataset.key]; schPut({ barEnd: be }); renderHomeSched();
    try { await schSave(); toast('막대 길이를 원래대로 돌렸습니다.'); } catch (er) { toast('저장하지 못했습니다.\n' + er.message, 'err'); } });
  $('homeSched').addEventListener('mousedown', e => { const w = e.target.closest('.og-wrap'); if (!w || e.button !== 0 || e.target.closest('.og-rz')) return; drag = { w, x: e.clientX, s: w.scrollLeft, moved: false }; w.classList.add('drag'); e.preventDefault(); });
  document.addEventListener('mousemove', e => { if (!drag) return; const dx = e.clientX - drag.x; if (Math.abs(dx) > 3) drag.moved = true; drag.w.scrollLeft = drag.s - dx; });
  document.addEventListener('mouseup', () => { if (drag) { sch.dragMoved = drag.moved; drag.w.classList.remove('drag'); drag = null; } });
  $('homeSched').addEventListener('change', async e => {
    if (e.target.id === 'scSe') { schPut({ season: e.target.value }); renderHomeSched(); return; }
    // 일정 추가 시즌을 고르면 그 시즌 생산성(하루 평균)을 옆에 보여 줌 — 추가하면 이 값으로 기간 계산
    if (e.target.id === 'ogSe' || e.target.id === 'ogGrp') { const S = schSpOf({ se: $('ogSe').value, grp: $('ogGrp').value });
      $('ogAvg').innerHTML = `${esc(S.how)} <b>${fmt(Math.round(S.v))}</b>장`; return; }
    // 인원을 바꾸면 바로 적용 · 저장 → 하루 장수 · 끝나는 날 · 뒤 일정이 모두 다시 계산됨
    if (e.target.id === 'ogCrew') { const n = Math.round(+e.target.value); if (!(n >= SC_MIN)) { toast(`인덕션 1대를 돌리려면 ${SC_MIN}명 이상이 필요합니다.`, 'err'); return; }
      schPut({ crew: Object.assign({}, schCfg().crew || {}, { [e.target.dataset.ck]: n }) }); renderHomeSched();
      try { await schSave(); toast(`인원 ${n}명으로 일정을 다시 계산했습니다.`); } catch (er) { toast('저장하지 못했습니다.\n' + er.message, 'err'); } }
    // 추가 일정 장수 바꾸기 (마스터 2026-11-12) → 바로 저장 · 끝나는 날 · 뒤 일정 다시 계산
    if (e.target.id === 'ogExQ') { const q = Math.round(+e.target.value), id = e.target.dataset.ex; if (String(e.target.value).trim() === '' || !(q >= 0)) { toast('장수를 0 이상으로 넣어 주세요.', 'err'); return; }
      const be = Object.assign({}, schCfg().barEnd || {}); delete be['x|' + id];   // 끌어서 정해 둔 끝 날은 풀고 장수로 다시 계산
      schPut({ extra: (schCfg().extra || []).map(x => x.id === id ? Object.assign({}, x, { q }) : x), barEnd: be }); renderHomeSched();
      try { await schSave(); toast(`${fmt(q)}장으로 일정을 다시 계산했습니다.`); } catch (er) { toast('저장하지 못했습니다.\n' + er.message, 'err'); } }
  });
}
// 설정 바꾸기 (순서는 바로 저장 · 시즌 · 하루 장수는 [설정 저장])
function schPut(o) { const all = state.schedAll = state.schedAll || {}; all[scopeKey()] = Object.assign({}, schCfg(), o); }

/* ---------------- 소터분류 → 박스 소요량 ----------------
   시즌 · 복종별: 검수 완료 장수(schRemain · 검수 전 예정 추정치는 넣지 않음 — 마스터 2026-11-02) ÷ 입수량(packMap 그 시즌) → 필요 박스 (올림)
   쓴 박스 = 소터 파일 마지막 작업일의 박스 누적(sorter_result.boxes) · 더 필요한 박스 = 남은 장수 ÷ 입수량 */
const bn = { se: '' };
function boxNeedRows(se) {
  const R = schRemain(se); if (!R) return null;
  const ds = [...new Set(state.sorter_result.map(r => r.work_date).filter(Boolean))].sort(), d = ds[ds.length - 1], used = {}, usedQ = {};
  // 쓴 박스: 마지막 작업일 파일 + 그 파일에 없는 스타일은 마지막으로 올라온 날의 줄 (소터 판을 새로 시작한 날 여름 티셔츠 · 자켓이 0이 되지 않게 · 11/4)
  const keepSe = state.filter.season; state.filter.season = ''; const snap = sorterSnap(); state.filter.season = keepSe;
  (snap.get(d) || []).forEach(r => { if (styleSeason(r.style) === se) { const g = groupOf(r.style) || '기타'; used[g] = (used[g] || 0) + (r.boxes || 0); usedQ[g] = (usedQ[g] || 0) + (r.boxed_qty || 0); } });
  const pk = packMap(se);
  return { d, rows: R.grps.map(g => { const pack = +pk[g.grp] || 0, total = g.tq;   // 검수된 장수만 (검수 전 예정을 비율로 나눈 추정치는 넣지 않음)
    return { grp: g.grp, pack, total, done: g.done, rem: g.rem, need: pack ? Math.ceil(total / pack) : null, used: used[g.grp] || 0, perBox: used[g.grp] ? (usedQ[g.grp] || 0) / used[g.grp] : 0, more: pack ? Math.ceil(g.rem / pack) : null }; }) };
}
// 시즌: 대시보드처럼 S/S · F/W 버튼 (처음 값은 지금 작업 중인 시즌) — S/S면 위에 봄 · 아래 여름, 맨 아래 S/S 합계(복종마다 한 줄) — 마스터 2026-11-04
// 입수량은 시즌마다 달라 시즌별로 계산해 더함
function boxNeedSet(h) {
  const L = (SE_GROUP[h] || [h]).map(se => { const B = boxNeedRows(se); return B && B.rows.length ? Object.assign(B, { se }) : null; }).filter(Boolean);
  if (!L.length) return null;
  const M = new Map();
  L.forEach(B => B.rows.forEach(r => {
    const o = M.get(r.grp) || M.set(r.grp, { grp: r.grp, packs: [], total: 0, done: 0, rem: 0, used: 0, usedQ: 0, need: null, more: null }).get(r.grp);
    o.packs.push([B.se, r.pack]); ['total', 'done', 'rem', 'used'].forEach(f => { o[f] += r[f] || 0; }); o.usedQ += (r.perBox || 0) * (r.used || 0);
    if (r.need != null) { o.need = (o.need || 0) + r.need; o.more = (o.more || 0) + r.more; }   // 입수량 없는 시즌은 박스 계산에서 빠짐 (아래 안내)
  }));
  // 합계 줄 입수량: 시즌마다 같으면 숫자 하나, 다르면 「봄 50 · 여름 70」
  const packTxt = ps => { const v = [...new Set(ps.map(p => p[1] || 0))]; return v.length === 1 ? (v[0] ? fmt(v[0]) : '') : ps.map(([s, q]) => s + ' ' + (q ? fmt(q) : '미지정')).join(' · '); };
  const parts = L.map(B => ({ se: B.se, rows: B.rows.map(r => Object.assign({ packTxt: r.pack ? fmt(r.pack) : '' }, r)) }));
  const total = [...M.values()].map(o => Object.assign(o, { packTxt: packTxt(o.packs), perBox: o.used ? o.usedQ / o.used : 0 }));
  return { d: L[0].d, parts, total, noPack: L.flatMap(B => B.rows.filter(r => !r.pack).map(r => B.se + ' ' + grpName(r.grp))) };
}
function renderBoxNeed() {
  if (!SE_GROUP[bn.se]) bn.se = hseAuto();
  $('bnSeBtns').innerHTML = hseGrps().map(g => `<button class="btn sm ${g === bn.se ? '' : 'line'}" data-bnse="${esc(g)}">${esc(seasonPickName(g))}</button>`).join(' ');
  $('bnSeBtns').onclick = e => { const b = e.target.closest('[data-bnse]'); if (b) { bn.se = b.dataset.bnse; renderBoxNeed(); } };
  $('bnXlsx').onclick = downloadBoxNeed;
  const S = boxNeedSet(bn.se);
  if (!S) { $('bnTable').innerHTML = `<div class="empty">${esc(seasonPickName(bn.se))} 반품예정 · 반품검수 · 소터 자료가 있어야 계산합니다.</div>`; return; }
  const sum = (L, k) => L.reduce((a, r) => a + (r[k] || 0), 0);
  const line = (lb, r, first, n) => `<tr>${first ? `<td rowspan="${n}"><b>${lb}</b></td>` : ''}<td><b>${esc(grpName(r.grp))}</b></td><td>${r.packTxt ? esc(r.packTxt) : '<span class="ng">미지정</span>'}</td><td>${fmt(Math.round(r.total))}</td><td><b>${r.need == null ? '-' : fmt(r.need)}</b></td><td>${fmt(r.used)}</td><td>${r.perBox ? fmt(Math.round(r.perBox)) : '-'}</td><td>${fmt(Math.round(r.rem))}</td><td>${r.more == null ? '-' : fmt(r.more)}</td><td><b>${r.more == null ? '-' : fmt(r.used + r.more)}</b></td></tr>`;
  const tot = (lb, L) => `<tr class="tot"><td colspan="3"><b>${lb}</b></td><td>${fmt(Math.round(sum(L, 'total')))}</td><td><b>${fmt(sum(L, 'need'))}</b></td><td>${fmt(sum(L, 'used'))}</td><td></td><td>${fmt(Math.round(sum(L, 'rem')))}</td><td>${fmt(sum(L, 'more'))}</td><td><b>${fmt(sum(L, 'used') + sum(L, 'more'))}</b></td></tr>`;
  const block = (lb, rows, tl) => rows.map((r, i) => line(lb, r, !i, rows.length)).join('') + tot(tl, rows);
  const hn = esc(seasonPickName(bn.se));
  $('bnTable').innerHTML = `<table><tr><th>시즌</th><th>복종</th><th>입수량</th><th>검수 완료(장)</th><th>필요 박스</th><th>쓴 박스 <span class="na">${esc(S.d ? S.d.slice(5).replace('-', '/') : '')}까지</span></th><th>실제 박스당 장수</th><th>남은 장수</th><th>더 필요한 박스</th><th>예상 총 박스</th></tr>
    ${S.parts.map(B => block(esc(B.se), B.rows, esc(B.se) + ' 소계')).join('')}
    ${S.parts.length > 1 ? block(hn + ' 합계', S.total, hn + ' 합계') : ''}</table>
    ${S.noPack.length ? `<div class="na" style="margin-top:6px">입수량 미지정 ${S.noPack.map(esc).join(' · ')}는 박스 계산에서 빠졌습니다 — [오토 RCV › 복종별 기본 입수량]에서 넣어 주세요.</div>` : ''}
    <div class="na" style="margin-top:6px">필요 박스는 박스를 입수량대로 꽉 채운다고 본 값입니다. 실제로는 스타일이 끝날 때 덜 찬 박스(잔량 박스)가 생겨 '예상 총 박스'가 조금 더 많습니다.</div>`;
}
function downloadBoxNeed() {
  const S = boxNeedSet(bn.se); if (!S) { toast('받을 자료가 없습니다.', 'err'); return; }
  const hn = seasonPickName(bn.se), xr = (lb, r) => [lb, grpName(r.grp), r.packTxt || '', Math.round(r.total), r.need ?? '', r.used, r.perBox ? Math.round(r.perBox) : '', Math.round(r.rem), r.more ?? '', r.more == null ? '' : r.used + r.more];
  const rows = [[`박스 소요량 (${centerName()} · ${hn}) — 소터 ${S.d || '-'} 기준`], ['시즌', '복종', '입수량', '검수 완료(장)', '필요 박스', '쓴 박스', '실제 박스당 장수', '남은 장수', '더 필요한 박스', '예상 총 박스']]
    .concat(S.parts.flatMap(B => B.rows.map(r => xr(B.se, r))), S.parts.length > 1 ? S.total.map(r => xr(hn + ' 합계', r)) : []);
  const a = document.createElement('a'); a.href = URL.createObjectURL(xlsxBlob(rows, '박스소요량')); a.download = `박스소요량_${hn.replace('/', '')}_${todayStr().replace(/-/g, '')}.xlsx`; a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
}
